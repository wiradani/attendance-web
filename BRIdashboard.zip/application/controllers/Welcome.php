<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct()
    {
		parent::__construct();
		$this->load->model("admin/EdcModel");
		$this->load->model("admin/CountEdcModel");
		$this->load->model("admin/ValueFilterModel");
		$this->load->library('session');
		$session = $this->session->userdata('userdata');
	}

	public function index()
	{	
	  $valueTimer =$this->session->flashdata('valueTimer');
	  $btn =$this->session->flashdata('btn');

	  if($valueTimer == null){
		$valueTimer = 43200;
	  }

	  if($btn == null){
		  $btn = "area";
	  }
	  
	  $data['btn'] = $btn;
	  $data['valueTimer'] = $valueTimer;


	  $data['total_merchant'] = $this->EdcModel->getTotalMerchant();
	  $data['total_terminal'] = $this->EdcModel->getTotalTerminal();
	  $data['total_area'] = $this->EdcModel->getTotalArea();
	  $data['total_kanwil'] = $this->EdcModel->getTotalKANWIL();
	  $data['total_kcp'] = $this->EdcModel->getTotalKCP();
	  $data['total_edc_active']  = $this->EdcModel->getTotalActiveTerminal($valueTimer);
	  // total edc weekly (current month only)
	  $data["total_daily"] = $this->EdcModel->getEDCWeekly();

	  $data['data_edc_area'] = $this->EdcModel->getAllArea($valueTimer);
	  $data['data_edc_kanwil'] = $this->EdcModel->getAllKanwil($valueTimer);
	  $data['line_graph'] = $this->ValueFilterModel->getLine($valueTimer);
	  $data['line_graph_kanwil'] = $this->ValueFilterModel->getLineKanwil($valueTimer);
	  $data['line_graph_kcp'] = $this->ValueFilterModel->getLineKCP($valueTimer);

	  $this->load->view("admin/overview",$data);
	}

	public function about()
	{
		$this->load->view('about.php');
	}

	public function contact()
	{
		$this->load->view('contact.php');
	}
}
