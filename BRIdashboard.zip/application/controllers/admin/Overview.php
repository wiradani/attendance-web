<?php

class Overview extends CI_Controller {
    public function __construct()
    {
		parent::__construct();

		
	}

	public function index()
	{
	  $this->load->views("admin/overview",$data);
	}

	public function UpdateTimerGraph(){
		$session = $this->session->userdata('userdata');
		  
		  if ($_POST['timerPost'] == 0) {
			$session = ['valueTimer' => '1440'];
		  }else{
			$session = ['valueTimer' => $_POST['timerPost']];
		  }
		  $this->session->set_userdata($session);
		
	  }


	  public function UpdateTimer(){
		$session = $this->session->userdata('userdata');
		
		  $data['userdata'] = $this->userdata;
		  if ($_POST['timerPost'] == 0) {

			$session = ['valueTimer' => '1440'];
		  }else{
			$session = ['valueTimer' => $_POST['timerPost']];
		  }
		  $this->session->set_userdata($session);
		
	  }

	public function queryParameter(){

		$this->load->library('session');


		$this->session->set_flashdata('valueTimer',  $this->input->post('tolerance'));
		$this->session->set_flashdata('btn',  $this->input->post('btn'));
		$valueTimer =$this->session->flashdata('valueTimer');
		if($valueTimer == null){
			$this->load->view('about.php');
		}
		else {
			redirect('/welcome/index');
		}
		
	  
	}

}

