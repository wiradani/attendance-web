<?php
  class Export extends CI_Controller  {
    public function __construct() {
      parent::__construct();
      $this->load->model("admin/ReportModel");
      
    }


    public function Export_Excel_All_Merchant(){
        // Load plugin PHPExcel nya
        include APPPATH.'third_party/PHPExcel/PHPExcel.php';
        
        // Panggil class PHPExcel nya
        $excel = new PHPExcel();
  
        // Settingan awal fil excel
        $excel->getProperties()->setCreator('PT. Pasifik Cipta Solusi')
                     ->setLastModifiedBy('PT. Pasifik Cipta Solusi')
                     ->setTitle("Export All EDC")
                     ->setSubject("EDC Merchant")
                     ->setDescription("Export All EDC")
                     ->setKeywords("EDC Merchant");
  
        // Buat sebuah variabel untuk menampung pengaturan style dari header tabel
        $style_col = array(
          'font' => array('bold' => true), // Set font nya jadi bold
          'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
          ),
          'borders' => array(
            'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
            'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
            'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
            'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
          )
        );
  
        // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
        $style_row = array(
          'alignment' => array(
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
          ),
          'borders' => array(
            'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
            'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
            'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
            'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
          )
        );
  
        // $excel->setActiveSheetIndex(0)->setCellValue('A1', "EDC SPBU"); // Set kolom A1 dengan tulisan "DATA SISWA"
        // $excel->getActiveSheet()->mergeCells('A1:E1'); // Set Merge Cell pada kolom A1 sampai E1
        $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE); // Set bold kolom A1
        $excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(11); // Set font size 15 untuk kolom A1
        $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); // Set text center untuk kolom A1
  
        // Buat header tabel nya pada baris ke 3
        $excel->setActiveSheetIndex(0)->setCellValue('A1', "Merchant CODE");
        $excel->setActiveSheetIndex(0)->setCellValue('B1', "Merchant NAME");
        $excel->setActiveSheetIndex(0)->setCellValue('C1', "Kantor Wilayah");
        $excel->setActiveSheetIndex(0)->setCellValue('D1', "KCP");
        $excel->setActiveSheetIndex(0)->setCellValue('E1', "Area");
        $excel->setActiveSheetIndex(0)->setCellValue('F1', "ADDRESS");
        $excel->setActiveSheetIndex(0)->setCellValue('G1', "LAST HEARTBEAT");
  
        // Apply style header yang telah kita buat tadi ke masing-masing kolom header
        $excel->getActiveSheet()->getStyle('A1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('B1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('C1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('D1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('E1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('F1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('G1')->applyFromArray($style_col);
  
        // Panggil function view yang ada di SiswaModel untuk menampilkan semua data siswanya
  
        $siswa = $this->ReportModel->getExportAllMerchantFromTerminal();
  
        $no = 1; // Untuk penomoran tabel, di awal set dengan 1
        $numrow = 2; // Set baris pertama untuk isi tabel adalah baris ke 4
        foreach($siswa as $myData){ // Lakukan looping pada variabel siswa
          $excel->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $myData->merchant_code);
          $excel->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $myData->merchant_name);
          $excel->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $myData->kanwil);
          $excel->setActiveSheetIndex(0)->setCellValue('D'.$numrow, $myData->kcp);
          $excel->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $myData->area);
          $excel->setActiveSheetIndex(0)->setCellValue('F'.$numrow, $myData->address);
          $excel->setActiveSheetIndex(0)->setCellValue('G'.$numrow, $myData->created_date);
          
          // Apply style row yang telah kita buat tadi ke masing-masing baris (isi tabel)
          $excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('B'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('D'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('F'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('G'.$numrow)->applyFromArray($style_row);
          
          $no++; // Tambah 1 setiap kali looping
          $numrow++; // Tambah 1 setiap kali looping
        }
  
        // Set width kolom
        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(15); // Set width kolom B
        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(25); // Set width kolom C
        
        // Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
        $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);
  
        // Set orientasi kertas jadi LANDSCAPE
        $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
  
        // Set judul file excel nya
        $excel->getActiveSheet(0)->setTitle("Export Data All Merchant");
        $excel->setActiveSheetIndex(0);
        
        $filename = "EDC Merchant - Export All Merchant ".date('Y-m-d H-i-s').".xlsx";
        // Proses file excel
        // header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        // header('Content-Disposition: attachment; filename="'.$filename.'"'); // Set nama file excel nya
        // header('Cache-Control: max-age=0');
  
        // $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        // $write->save('php://output');
        $objWriter = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        ob_end_clean();
        // We'll be outputting an excel file
        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        $objWriter->save('php://output');
      }


      public function Export_Excel_All_Edc(){
        // Load plugin PHPExcel nya
        include APPPATH.'third_party/PHPExcel/PHPExcel.php';
        
        // Panggil class PHPExcel nya
        $excel = new PHPExcel();
  
        // Settingan awal fil excel
        $excel->getProperties()->setCreator('PT. Pasifik Cipta Solusi')
                     ->setLastModifiedBy('PT. Pasifik Cipta Solusi')
                     ->setTitle("Export All EDC")
                     ->setSubject("EDC Merchant")
                     ->setDescription("Export All EDC")
                     ->setKeywords("EDC Merchant");
  
        // Buat sebuah variabel untuk menampung pengaturan style dari header tabel
        $style_col = array(
          'font' => array('bold' => true), // Set font nya jadi bold
          'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
          ),
          'borders' => array(
            'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
            'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
            'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
            'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
          )
        );
  
        // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
        $style_row = array(
          'alignment' => array(
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
          ),
          'borders' => array(
            'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
            'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
            'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
            'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
          )
        );
  
        // $excel->setActiveSheetIndex(0)->setCellValue('A1', "EDC SPBU"); // Set kolom A1 dengan tulisan "DATA SISWA"
        // $excel->getActiveSheet()->mergeCells('A1:E1'); // Set Merge Cell pada kolom A1 sampai E1
        $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE); // Set bold kolom A1
        $excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(11); // Set font size 15 untuk kolom A1
        $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); // Set text center untuk kolom A1
  
        // Buat header tabel nya pada baris ke 3
        $excel->setActiveSheetIndex(0)->setCellValue('A1', "SN");
        $excel->setActiveSheetIndex(0)->setCellValue('B1', "Merchant CODE");
        $excel->setActiveSheetIndex(0)->setCellValue('C1', "Merchant NAME");
        $excel->setActiveSheetIndex(0)->setCellValue('D1', "KCP");
        $excel->setActiveSheetIndex(0)->setCellValue('E1', "Kantor Wilayah");
        $excel->setActiveSheetIndex(0)->setCellValue('F1', "Area");
        $excel->setActiveSheetIndex(0)->setCellValue('G1', "ADDRESS");
        $excel->setActiveSheetIndex(0)->setCellValue('H1', "DEVICE TYPE");
        $excel->setActiveSheetIndex(0)->setCellValue('I1', "DCM VERSION");
        $excel->setActiveSheetIndex(0)->setCellValue('J1', "LAST HEARTBEAT");
  
        // Apply style header yang telah kita buat tadi ke masing-masing kolom header
        $excel->getActiveSheet()->getStyle('A1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('B1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('C1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('D1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('E1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('F1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('G1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('H1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('I1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('J1')->applyFromArray($style_col);
        
  
        // Panggil function view yang ada di SiswaModel untuk menampilkan semua data siswanya
  
        $siswa = $this->ReportModel->getExportAllEdcFromTerminal();
  
        $no = 1; // Untuk penomoran tabel, di awal set dengan 1
        $numrow = 2; // Set baris pertama untuk isi tabel adalah baris ke 4
        foreach($siswa as $myData){ // Lakukan looping pada variabel siswa
          $excel->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $myData->sn);
          $excel->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $myData->merchant_code);
          $excel->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $myData->merchant_name);
          $excel->setActiveSheetIndex(0)->setCellValue('D'.$numrow, $myData->kcp);
          $excel->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $myData->kanwil);
          $excel->setActiveSheetIndex(0)->setCellValue('F'.$numrow, $myData->area);
          $excel->setActiveSheetIndex(0)->setCellValue('G'.$numrow, $myData->address);
          $excel->setActiveSheetIndex(0)->setCellValue('H'.$numrow, $myData->device_type);
          $excel->setActiveSheetIndex(0)->setCellValue('I'.$numrow, $myData->dcm_version);
          $excel->setActiveSheetIndex(0)->setCellValue('J'.$numrow, $myData->created_date);
          
          // Apply style row yang telah kita buat tadi ke masing-masing baris (isi tabel)
          $excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('B'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('D'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('F'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('G'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('H'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('I'.$numrow)->applyFromArray($style_row);
          $excel->getActiveSheet()->getStyle('J'.$numrow)->applyFromArray($style_row);

          
          $no++; // Tambah 1 setiap kali looping
          $numrow++; // Tambah 1 setiap kali looping
        }
  
        // Set width kolom
        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(15); // Set width kolom B
        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(25); // Set width kolom C
        
        // Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
        $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);
  
        // Set orientasi kertas jadi LANDSCAPE
        $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
  
        // Set judul file excel nya
        $excel->getActiveSheet(0)->setTitle("Export Data All Edc");
        $excel->setActiveSheetIndex(0);
        
        $filename = "EDC Merchant - Export All EDC ".date('Y-m-d H-i-s').".xlsx";
        $objWriter = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        ob_end_clean();
        // We'll be outputting an excel file
        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        $objWriter->save('php://output');
      }
}