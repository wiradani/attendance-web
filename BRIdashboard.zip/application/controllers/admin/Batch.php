<?php
class Batch extends CI_Controller{    

    private $filename = "import_batch_edc";

    public function __construct() {
        parent::__construct();
        $this->load->model("admin/EdcModel");
        
        include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    }

    public function Batch() {

        $data['status'] = 'add';
        $data['title'] = 'Import Batch EDC';
		
        $this->load->view('admin/batch/batch',$data);
    }


    public function Preview(){

        $excel = new PHPExcel();
        $data = array();
       

        
        $data['status'] = 'add';
       
    
        $upload = $this->EdcModel->Upload_Batch_Edc($this->filename);

        
        if($upload['result'] == "success"){ // Jika proses upload sukses   
                   
            $excelreader = new PHPExcel_Reader_Excel2007();
            $loadexcel = $excelreader->load('assets/excel/'.$this->filename.'.xlsx');
            $sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);
        
            $data['sheet'] = $sheet; 

            
        }else{
            $data['upload_error'] = $upload['error'];
 
        }
  
        $data['title'] = "Import Batch EDC";
        $this->load->view('admin/batch/batch',$data);
    }

    public function Export(){
        // Panggil class PHPExcel nya
        $excel = new PHPExcel();
            

        // Buat sebuah variabel untuk menampung pengaturan style dari header tabel
        $style_col = array(
            'font' => array(
                'bold' => true
            ), // Set font nya jadi bold
            'alignment' => array(
                'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
                'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
            ),
            'borders' => array(
                'top' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN
                ), // Set border top dengan garis tipis
                'right' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN
                ), // Set border right dengan garis tipis
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN
                ), // Set border bottom dengan garis tipis
                'left' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN
                ) // Set border left dengan garis tipis
            )
        );
        
        // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
        $style_row = array(
            'alignment' => array(
                'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
            ),
            'borders' => array(
                'top' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN
                ), // Set border top dengan garis tipis
                'right' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN
                ), // Set border right dengan garis tipis
                'bottom' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN
                ), // Set border bottom dengan garis tipis
                'left' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN
                ) // Set border left dengan garis tipis
            )
        );
            
        // Settingan awal fil excel
        $excel->getProperties()->setCreator('PT. Pasifik Cipta Solusi')->setLastModifiedBy('PT. Pasifik Cipta Solusi')->setTitle("Data")->setSubject("Transaction")->setDescription("Transaction")->setKeywords("Transaction");
        
        $excel->createSheet();
        $excel->setActiveSheetIndex();
        $excel->getActiveSheet()->setTitle('Sheet 1');

        // Buat header tabel nya pada baris ke 3
        $excel->setActiveSheetIndex()->setCellValue('A1', "No.");
        $excel->setActiveSheetIndex()->setCellValue('B1', "SN");
        $excel->setActiveSheetIndex()->setCellValue('C1', "Merchant Code");
        $excel->setActiveSheetIndex()->setCellValue('D1', "Merchant Name");
        $excel->setActiveSheetIndex()->setCellValue('E1', "Address");
        $excel->setActiveSheetIndex()->setCellValue('F1', "Area");
        $excel->setActiveSheetIndex()->setCellValue('G1', "Kantor Wilayah");
        $excel->setActiveSheetIndex()->setCellValue('H1', "KCP");

        $excel->getActiveSheet()->getStyle('A1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('B1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('C1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('D1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('E1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('F1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('G1')->applyFromArray($style_col);
        $excel->getActiveSheet()->getStyle('H1')->applyFromArray($style_col);
        

        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(5); // Set width kolom A
        $excel->getActiveSheet()->getColumnDimension('B')->setWidth(25); 
        $excel->getActiveSheet()->getColumnDimension('C')->setWidth(25); 
        $excel->getActiveSheet()->getColumnDimension('D')->setWidth(25); 
        $excel->getActiveSheet()->getColumnDimension('E')->setWidth(25); 
        $excel->getActiveSheet()->getColumnDimension('F')->setWidth(25); 
        $excel->getActiveSheet()->getColumnDimension('G')->setWidth(25); 
        $excel->getActiveSheet()->getColumnDimension('H')->setWidth(25);

        
        $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);
        $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
        
        // Set judul file excel nya
        $excel->getActiveSheet(1)->setTitle("Template Batch Upload EDC");
        $excel->setActiveSheetIndex(0);
        
        $filename  = "Template Batch Upload EDC " . date('Y-m-d H-i-s') . ".xlsx";
        $objWriter = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        ob_end_clean();
        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $objWriter->save('php://output');

    }

    public function Import(){

        $excelreader = new PHPExcel_Reader_Excel2007();
        $loadexcel = $excelreader->load('assets/excel/'.$this->filename.'.xlsx');
        $sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);
        $importData = array();
        $numrow = 1;
        $data = array();
        $insert = array();

        $insertData = array();

        
        $data['title'] = 'Import Batch EDC';
        $data['status'] = "add";
        
        
    
            foreach($sheet as $row){
            // Cek $numrow apakah lebih dari 1
            // Artinya karena baris pertama adalah nama-nama kolom
            // Jadi dilewat saja, tidak usah diimport
                if($numrow > 1){
                    // Kita push (add) array data ke variabel data
                    array_push($importData, array(
                    'sn'=>$row['B'], 
                    'merchant_code'=>$row['C'], 
                    'merchant_name'=>$row['D'], 
                    'address'=>$row['E'], 
                    'area'=>$row['F'], 
                    'kanwil'=>$row['G'], 
                    'kcp'=>$row['H'], 
                    ));
                }
                
                $numrow++; // Tambah 1 setiap kali looping
            }
        

            for($i=0; $i < count($importData); $i++){
                $checkUnique = $this->EdcModel->isUnique($importData[$i]);
               
                if($checkUnique->num_rows() > 0){
                    $this->EdcModel->updateEdcExcel($importData[$i]);
                } else{
                    $this->EdcModel->insertEdcExcel($importData[$i]);
                }

            }
            
            redirect('/welcome/index');
            
           

    }








}