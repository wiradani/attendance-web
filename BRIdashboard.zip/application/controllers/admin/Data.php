<?php
class Data extends CI_Controller{     
    public function __construct() {
        parent::__construct();
        $this->load->model("admin/DataModelArea");
        $this->load->model("admin/CountMerchantTerminalModel");
        $this->load->model("admin/CDT");
        $this->load->model("admin/DataTregWitel");
        $this->load->model("admin/ValueFilterModel");
        $this->load->model("admin/DataModelKcp");
     
    }

    public function index(){
        header("Refresh: 300");
        $valueTimer =$this->session->flashdata('valueTimer');
        $btn =$this->session->flashdata('btn');

        if($valueTimer == null){
            $valueTimer = 1440;
        }

        if($btn == null){
            $btn = "area";
        }
        
        $data['btn'] = $btn;
        $data['valueTimer'] = $valueTimer;

        $data['data_area'] = $this->DataModelArea->getTableArea($valueTimer)['mor'];
        $data['data_kanwil'] = $this->DataTregWitel->getTregWitel($valueTimer)['TregWitel'];
        $data['data_kcp'] = $this->DataModelKcp->getTableKcp($valueTimer)['mor'];

        $data['merchant_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['1'];
        $data['merchant_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['2'];
        $data['terminal_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['3'];
        $data['terminal_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['4'];

        $this->load->view('admin/layout_data/data', $data);
    }

    public function queryParameter(){

		$this->load->library('session');


		$this->session->set_flashdata('valueTimer',  $this->input->post('tolerance'));
		$this->session->set_flashdata('btn',  $this->input->post('btn'));
		$valueTimer =$this->session->flashdata('valueTimer');
		if($valueTimer == null){
			$this->load->view('about.php');
		}
		else {
			redirect('admin/data/index');
		}	  
    }
    

    public function area_status(){
        
      header("Refresh: 300");
      $valueTimer =$this->session->userdata('valueTimer');

      if($valueTimer == null){
        $valueTimer = 1440;
      }
        
      $data['valueTimer'] = $valueTimer;

      $param1 = $this->uri->segment('4');
      $array_status = explode("_",$param1);

      $param1 = str_replace('%20', ' ', $array_status[1]); 
      if (is_numeric($param1) || $param1 == "X") {
          if ($array_status[0] == "connected") {
              $data['area_status'] = $this->CDT->getAreaConnected($param1,$valueTimer)['area'];
              $data['kanwil'] = false;
          }elseif ($array_status[0] == "disconnected") {
              $data['area_status'] = $this->CDT->getAreaDisconnected($param1,$valueTimer)['area'];
              $data['kanwil'] = false;
          }elseif ($array_status[0] == "total") {
              $data['area_status'] = $this->CDT->getAreaTotal($param1,$valueTimer)['area'];
              $data['kanwil'] = false;
          }
          $data['merchant_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['1'];
          $data['merchant_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['2'];
          $data['terminal_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['3'];
          $data['terminal_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['4'];
      }else{
          if ($array_status[0] == "connected") {
              $data['area_status'] = $this->CDT->getMorWitelConnected($param1,$valueTimer)['mor'];
              $data['kanwil'] = true;
          }elseif ($array_status[0] == "disconnected") {
              $data['area_status'] = $this->CDT->getMorWitelDisconnected($param1,$valueTimer)['mor'];
              $data['kanwil'] = true;
          }elseif ($array_status[0] == "total") {
              $data['area_status'] = $this->CDT->getMorWitelTotal($param1,$valueTimer)['mor'];
              $data['kanwil'] = true;
          }
          $data['merchant_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['1'];
          $data['merchant_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['2'];
          $data['terminal_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['3'];
          $data['terminal_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['4'];
      }
      $this->load->view('admin/layout_data/data_cdt_status', $data);
  }

  public function area_Terminal(){
        header("Refresh: 300");
        $data['status'] = $this->session->userdata('userdata');
        
        $data['valueTimer'] = $this->session->userdata('valueTimer');
        $valueTimer = $this->session->userdata('valueTimer');

        if($valueTimer == null){
            $valueTimer = 1440;
          }

        $param1 = $this->uri->segment('4');
        $array_status = explode("_",$param1);

        $data['merchant_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['1'];
        $data['merchant_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['2'];
        $data['terminal_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['3'];
        $data['terminal_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['4'];

        if ($array_status[0] == "connected") {
            $data['terminal'] = $this->CDT->getAreaTerminalConnected($valueTimer,$array_status[1]);
        }elseif ($array_status[0] == "disconnected") {
            $data['terminal'] = $this->CDT->getAreaTerminalDisconnected($valueTimer,$array_status[1]);
        }elseif ($array_status[0] == "total") {
            $data['terminal'] = $this->CDT->getAreaTerminalTotal($valueTimer,$array_status[1]);
        }
        $this->load->view('admin/layout_data/data_cdt_terminal', $data);
    }


    public function area_Detail(){
        header("Refresh: 300");
        $data['status'] = $this->session->userdata('userdata');
        
        $data['valueTimer'] = $this->session->userdata('valueTimer');
        $valueTimer = $this->session->userdata('valueTimer');

        if($valueTimer == null){
            $valueTimer = 1440;
          }

        $param1 = $this->uri->segment('4');
        $param1 = str_replace('%20', ' ', $param1); 
        // if (is_numeric($param1) || $param1 == 'X' || $param1 == 'F' || $param1 == 'N') {
            $data['data_area2'] = $this->DataModelArea->getTableArea2($param1,$valueTimer)['mor'];

            $data['identity'] = "area";

            $data['merchant_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['1'];
            $data['merchant_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['2'];
            $data['terminal_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['3'];
            $data['terminal_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['4'];
        //  }
        //else{
        //     $array = explode("_",$param1);
        //     $data['data_area'] = $this->DataTregWitel->getareadmerchant($array[0], $array[1] ,$valueTimer)['mor'];	

        //     $data['identity'] = "kanwil";

        //     $data['merchant_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['1'];
        //     $data['merchant_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['2'];
        //     $data['terminal_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['3'];
        //     $data['terminal_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['4'];			
        // }
        
       
        $this->load->view('admin/layout_data/data_area_detail', $data);
    }


    public function Terminal(){
        header("Refresh: 300");
        $data['status'] = $this->session->userdata('userdata');
        
        $data['valueTimer'] = $this->session->userdata('valueTimer');
        $valueTimer = $this->session->userdata('valueTimer');   
        
        if($valueTimer == null){
            $valueTimer = 1440;
          }

        $param1 = $this->uri->segment('4');
        $param1 = str_replace('%20', ' ', $param1); 
        $data['terminal'] = $this->DataModelArea->getTerminal($param1,$valueTimer)['terminal'];

        $data['merchant_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['1'];
        $data['merchant_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['2'];
        $data['terminal_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['3'];
        $data['terminal_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['4'];

        $this->load->view('admin/layout_data/data_terminal', $data);
    }

//     //TR

    public function kanwil_status(){
        header("Refresh: 300");
        $data['status'] = $this->session->userdata('userdata');
        
        $data['valueTimer'] = $this->session->userdata('valueTimer');
        $valueTimer = $this->session->userdata('valueTimer'); 
        
        if($valueTimer == null){
            $valueTimer = 1440;
          }

        $kanwil = $this->uri->segment('4');

        if (substr("$kanwil", 0, 10) == "connected_") {
            $kanwil = str_replace('%20', ' ', $kanwil); 
            $kanwil = substr("$kanwil", 10, 30);
            $data['data_kanwil'] = $this->DataTregWitel->getkanwilConnected($kanwil,$valueTimer);
            $data['getUri'] = "byClose";
            $data['merchant_active'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['1'];
            $data['merchant_total'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['2'];
            $data['terminal_active'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['3'];
            $data['terminal_total'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['4'];
        }elseif(substr("$kanwil", 0, 13) == "disconnected_") {
            $kanwil = str_replace('%20', ' ', $kanwil); 
            $kanwil = substr("$kanwil", 13, 30);
            $data['data_kanwil'] = $this->DataTregWitel->getKanwillDisConnected($kanwil,$valueTimer);
            $data['getUri'] = "byClose";
            $data['merchant_active'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['1'];
            $data['merchant_total'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['2'];
            $data['terminal_active'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['3'];
            $data['terminal_total'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['4'];
        }elseif(substr("$kanwil", 0, 6) == "total_") {
            $kanwil = str_replace('%20', ' ', $kanwil); 
            $kanwil = substr("$kanwil", 6, 30);
            $data['data_kanwil'] = $this->DataTregWitel->getKanwilTotal($kanwil,$valueTimer);
            $data['getUri'] = "byClose";
            $data['merchant_active'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['1'];
            $data['merchant_total'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['2'];
            $data['terminal_active'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['3'];
            $data['terminal_total'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['4'];
        }else{
            $data['data_kanwil'] = $this->DataTregWitel->getareadmerchant($kanwil,$valueTimer)['kanwil'];
            $data['getUri'] = "byBack";
            $kanwil = str_replace('%20', ' ', $kanwil); 
            $data['merchant_active'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['1'];
            $data['merchant_total'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['2'];
            $data['terminal_active'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['3'];
            $data['terminal_total'] = $this->CountMerchantTerminalModel->getCountByKanwil($kanwil,$valueTimer)['4'];
        }
        

        $this->load->view('admin/layout_data/data_kanwil_detail', $data);
    }



    public function kcp_status(){
        
        header("Refresh: 300");
        $valueTimer =$this->session->userdata('valueTimer');
  
        if($valueTimer == null){
          $valueTimer = 1440;
        }
          
        $data['valueTimer'] = $valueTimer;
  
        $param1 = $this->uri->segment('4');
        $array_status = explode("_",$param1);
  
        $param1 = str_replace('%20', ' ', $array_status[1]); 
        // if (is_numeric($param1) || $param1 == "X") {
            if ($array_status[0] == "connected") {
                $data['kcp_status'] = $this->CDT->getKcpConnected($param1,$valueTimer)['area'];
                $data['kanwil'] = false;
            }elseif ($array_status[0] == "disconnected") {
                $data['kcp_status'] = $this->CDT->getKcpDisconnected($param1,$valueTimer)['area'];
                $data['kanwil'] = false;
            }elseif ($array_status[0] == "total") {
                $data['kcp_status'] = $this->CDT->getKcpTotal($param1,$valueTimer)['area'];
                $data['kanwil'] = false;
            }
            $data['merchant_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['1'];
            $data['merchant_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['2'];
            $data['terminal_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['3'];
            $data['terminal_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['4'];
        // }
        // else{
        //     if ($array_status[0] == "connected") {
        //         $data['kcp_status'] = $this->CDT->getMorWitelConnected($param1,$valueTimer)['mor'];
        //         $data['kanwil'] = true;
        //     }elseif ($array_status[0] == "disconnected") {
        //         $data['kcp_status'] = $this->CDT->getMorWitelDisconnected($param1,$valueTimer)['mor'];
        //         $data['kanwil'] = true;
        //     }elseif ($array_status[0] == "total") {
        //         $data['kcp_status'] = $this->CDT->getMorWitelTotal($param1,$valueTimer)['mor'];
        //         $data['kanwil'] = true;
        //     }
        //     $data['merchant_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['1'];
        //     $data['merchant_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['2'];
        //     $data['terminal_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['3'];
        //     $data['terminal_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['4'];
        // }
        $this->load->view('admin/layout_data/data_kcp_status', $data);
    }

//     ///////////////////////////////////////////////////////////////////////////////////////////////////////////
// 		//////////////////////////////////// SINGLE SN SEARCH v.1.0.1 /////////////////////////////////////////////
// 		///////////////////////////////////////////////////////////////////////////////////////////////////////////
		public function Single_Search(){
            $data['status'] = $this->session->userdata('userdata');
         
            $data['valueTimer'] = $this->session->userdata('valueTimer');
            $valueTimer = $this->session->userdata('valueTimer');

            if($valueTimer == null){
                $valueTimer = 1440;
              }

          $data['setFilterType'] = "";
            
          $data['setTolerance'] = 1;
          $data['setTime'] = "Day";
          $filterType = "";

          if (isset($_POST['search']) && !empty($_POST['serial_number']) && !empty($_POST['filter_type'])) {
              $value_search = $_POST['serial_number'];
              $tolerance 	= $this->session->userdata('valueTimer');
              $data['setTolerance'] = $_POST['filter_tolerance'];
              $data['setTime'] = $_POST['filter_time'];
              $data['setFilterType'] = $_POST['filter_type'];
              $filterType = $_POST['filter_type'];
              $data['serial_number'] = $value_search;

              //SPBU CODE or SERIAL NUMBER
              if ($filterType == "spbu") {
                  if ($_POST['filter_time'] == "Hour") {
                      $resvalue_search = $this->ValueFilterModel->getSerialNumberSearch($value_search);
                      $data['resvalue_search'] = $resvalue_search;
                      $data['result_search'] = $this->ValueFilterModel->getLineBySerialNumberSearchHour($resvalue_search, $data['setTolerance']);
                      $data['line_graph'] = $this->ValueFilterModel->getLineGraphTime($value_search, $data['setTolerance']);
                  }elseif ($_POST['filter_time'] == "Day") {
                      $resvalue_search = $this->ValueFilterModel->getSerialNumberSearch($value_search);
                      $data['resvalue_search'] = $resvalue_search;
                      $data['result_search'] = $this->ValueFilterModel->getLineBySerialNumberSearchDay($resvalue_search, $data['setTolerance']);
                      $data['line_graph'] = $this->ValueFilterModel->getLineGraph($value_search, $data['setTolerance']);
                  }
                  $data['single_search'] = $this->ValueFilterModel->getSingle_SearchMerchant($value_search, $data['setTolerance']);
              }elseif ($filterType == "sn") {
                  if ($_POST['filter_time'] == "Hour") {
                      $data['line_graph'] = $this->ValueFilterModel->getLineGraphTime($value_search, $data['setTolerance']);
                  }elseif ($_POST['filter_time'] == "Day") {
                      $data['line_graph'] = $this->ValueFilterModel->getLineGraph($value_search, $data['setTolerance']);
                  }
                  $data['single_search'] = $this->ValueFilterModel->getSingle_Search($value_search, $data['setTolerance']);
              }elseif ($filterType == "kanwil") {
                  $data['line_graph'] = $this->ValueFilterModel->getLineByKANWILSearch($_POST['filter_time'], $data['setTolerance'],$value_search);
              }elseif ($filterType == "area") {
                  $data['line_graph'] = $this->ValueFilterModel->getLineByAREASearch($_POST['filter_time'], $data['setTolerance'],$value_search);
              }

          }elseif(isset($_POST['search']) && empty($_POST['serial_number']) &&  $_POST['filter_type'] == "kanwil"){
              $value_search = "";
                  $tolerance 	= $this->session->userdata('valueTimer');
                  $data['setTolerance'] = $_POST['filter_tolerance'];
                  $data['setTime'] = $_POST['filter_time'];
                  $data['setFilterType'] = $_POST['filter_type'];
                  $data['serial_number'] = "";

                  $data['line_graphs'] = $this->ValueFilterModel->getLineByKANWILSearch($_POST['filter_time'], $data['setTolerance'],$value_search);
                  $data['single_search'] = [];
               
          }elseif(isset($_POST['search']) && empty($_POST['serial_number']) &&  $_POST['filter_type'] == "area"){
                  $value_search = "";
                  $tolerance 	= $this->session->userdata('valueTimer');
                  $data['setTolerance'] = $_POST['filter_tolerance'];
                  $data['setTime'] = $_POST['filter_time'];
                  $data['setFilterType'] = $_POST['filter_type'];
                  $data['serial_number'] = "";

                  $data['line_graphs'] = $this->ValueFilterModel->getLineByAREASearch($_POST['filter_time'], $data['setTolerance'],"");
                  // $data['single_search'] = [];
              $data['line_graph'] = $this->ValueFilterModel->getLineGraphTime(0, 0);
              
          }elseif(isset($_POST['search'])){
              $filterType = "";
              $data['result_search'] = [];
              $data['single_search'] = [];
              $data['serial_number'] = "";
              $data['setFilterType'] = $_POST['filter_type'];
              $data['line_graph'] = $this->ValueFilterModel->getLineGraphTime(0, 0);
          }else{
              $data['line_graph'] = $this->ValueFilterModel->getLineGraphTime(0, 0);
          }
          $data['merchant_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['1'];
          $data['merchant_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['2'];
          $data['terminal_active'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['3'];
          $data['terminal_total'] = $this->CountMerchantTerminalModel->getByArea($valueTimer)['4'];
          
         

          $this->load->view('admin/layout_data/data_single_search', $data);
      }

    
} 