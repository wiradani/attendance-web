<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>
<body id="page-top">

<?php $this->load->view("admin/_partials/navbar.php") ?>


<div id="wrapper">

	<?php $this->load->view("admin/_partials/sidebar.php") ?>

	<div id="content-wrapper">

		<div class="container-fluid">

		<div class="card mb-3" style="border: none;">
  			<form action="<?php echo base_url(); ?>index.php/admin/Overview/queryParameter" method='post' class="form-inline">

			<div class="input-group mb-2 mr-sm-2">
			<label for="tolerance">Tolerance</label>
			&nbsp
			<select id="tolerance" name="tolerance" clas="custom-select mr-sm-2">
				<option value="1440">Last 1 Days</option>
				<option value="2880">Last 2 Days</option>
				<option value="4320">Last 3 Days</option>
				<option value="7200">Last 5 Days</option>
				<option value="10080">Last 7 Days</option>
				<option value="20160">Last 14 Days</option>
				<option value="43200">Last 30 Days</option>
				<option value="86400">Last 60 Days</option>
				<option value="1290600">Last 90 Days</option>
			</select>
			</div>

			<div class="input-group mb-2 mr-sm-2">
			<label for="btn">Data</label>
			&nbsp
			<select id="btn" name="btn">
				<option value="area">Area</option>
				<option value="kanwil">Kanwil</option>
				<option value="kcp">KCP</option>
			</select>
			</div>

			<div class="input-group mb-2 mr-sm-2">
				<input class="btn btn-primary btn-sm " type="submit" value="Submit">
			</div>

  			</form>
		</div>

		<!-- Icon Cards-->
		<div class="row" style="align-content: center;">
			<div class="col-xl-3 col-sm-6 mb-3"> 
			<div class="card user-card text-white bg-primary o-hidden h-100" style="background: linear-gradient(45deg,#4099ff,#73b4ff);">
				<div class="card-body">
				<h5 class="card-title">EDC</h5>
				<div class="mr-5">
						<?php if ($total_edc_active != null) { ?>
                                Connected :	<?php echo $total_edc_active->result; ?>
                        <?php }else{ ?>
								Connected :   <?php echo '0'; ?>
                        <?php } ?>
					</div>
					<div class="mr-5">
						<?php if ($total_terminal != null) { ?>
                                Registerd :	<?php echo $total_terminal->sn; ?>
                        <?php }else{ ?>
								Registred :   <?php echo '0'; ?>
                        <?php } ?>
					</div>
					<div class="mr-5">
							Percent Connected: <?php echo round((($total_edc_active->result/$total_terminal->sn)*100),2) ;?>%
					</div>
				</div>
				
			</div>
			</div>
			<div class="col-xl-3 col-sm-6 mb-3">
			<div class="card text-white bg-warning o-hidden h-100" style="background: linear-gradient(45deg,#FFB64D,#ffcb80);">
				<div class="card-body">
				<h5 class="card-title">Merchant</h5>
					<div class="mr-5">
							<?php if ($total_merchant != null) { ?>
                                Total :	<?php echo $total_merchant->merchant; ?>
                                <?php }else{ ?>
								Total :   <?php echo '0'; ?>
                            <?php } ?>
					</div>
					<div class="mr-5">
							<?php if ($total_edc_active != null) { ?>
                                Merchant Connected :	<?php echo $total_edc_active->result; ?>
                                <?php }else{ ?>
								Merchant Connected :   <?php echo '0'; ?>
                            <?php } ?>
					</div>
				</div>
				
			</div>
			</div>
			<div class="col-xl-3 col-sm-6 mb-3">
			<div class="card user-card text-white bg-primary o-hidden h-100" style="background: linear-gradient(45deg,#4099ff,#73b4ff);">
				<div class="card-body">
				<h5 class="card-title">Area</h5>
					<div class="mr-5">
						<?php if ($total_area != null) { ?>
                            Total Area :	<?php echo $total_area->area; ?>
                            <?php }else{ ?>
							Total Area :   <?php echo '0'; ?>
                        <?php } ?>
					</div>
					<div class="mr-5">
						<?php if ($total_kanwil != null) { ?>
                            Total Kantor Wilayah :	<?php echo $total_kanwil->kanwil; ?>
                            <?php }else{ ?>
							Total Kantor Wilayah:   <?php echo '0'; ?>
                        <?php } ?>
					</div>
					<div class="mr-5">
						<?php if ($total_kcp != null) { ?>
                            Total KCP :	<?php echo $total_kcp->kcp; ?>
                            <?php }else{ ?>
							Total KCP:   <?php echo '0'; ?>
                        <?php } ?>
					</div>
				</div>
			</div>
			</div>
		</div>

		
		

		<div class="row">
    		<div class="col">
				<div class="card mb-3">
					<div class="card-header">
						<i class="fas fa-chart-area"></i>Chart</div>
						<div class="card-body">
							<div>            
								<div style="height: 0px auto; width: 0px auto; margin: 0px auto; padding: 10px;">
									<canvas style="height: 90px ; width: 240px;" id="<?php if($btn == 'area'){echo 'bar-chart';}else if($btn == 'kanwil'){echo 'bar-chart-kanwil';} else{echo 'bar-chart-kcp';}?>"></canvas>
									<!-- <canvas style="height: 90px ; width: 240px;" id="bar-chart"></canvas> -->
								</div>
							</div>
						</div>
					</div>
    			</div>
    		<div class="col">
			<div class="card mb-3">
					<div class="card-header">
						<i class="fas fa-chart-area"></i>Total EDC <?php echo date('M Y'); ?></div>
						<div class="card-body">
							<div>            
								<div style="height: 0px auto; width: 0px auto; margin: 0px auto; padding: 10px;">
									<canvas style="height: 90px ; width: 240px;" id="line-chart"></canvas>
								</div>
							</div>
						</div>
					</div>
    			</div>
    		</div>
  		</div>
		

	
		
		</div>

		</div>
		<!-- /.container-fluid -->

		<!-- Sticky Footer -->
		<?php $this->load->view("admin/_partials/footer.php") ?>

	</div>
	<!-- /.content-wrapper -->

</div>
<!-- /#wrapper -->


<?php $this->load->view("admin/_partials/scrolltop.php") ?>
<?php $this->load->view("admin/_partials/modal.php") ?>
<?php $this->load->view("admin/_partials/js.php") ?>
    
</body>
        



<script  type="text/javascript">
 new Chart(document.getElementById("line-chart"), {
  type: 'line',
  data: {
    labels: [<?php
	  $value = "";
	  for($i=0; $i < count($total_daily); $i++){
		if($i == 0){
		  $value = "'".$total_daily[$i]->date."','";
		}elseif($i == count($total_daily)-1){
		  $value .= $total_daily[$i]->date."'";
		}else{
		  $value .= $total_daily[$i]->date."','";
		}
	  }
	  echo $value;         
      ?>],
    datasets: [{ 
        data: [<?php foreach ($total_daily as $edc) { ?>
          <?php  echo (int)($edc->total);?>,
          <?php } ?>],
        label: "Total",
        borderColor: "#3e95cd",
        fill: false
      }
    ]
  },
  options: {
    title: {
      display: false,
    }
  }
});
</script>

<script>
new Chart(document.getElementById("bar-chart-kanwil"), {
    type: 'bar',
    data: {
	  labels: [<?php
	  $value = "";
	  for($i=0; $i < count($line_graph_kanwil); $i++){
		if($i == 0){
		  $value = "'".$line_graph_kanwil[$i]->kanwil."','";
		}elseif($i == count($line_graph_kanwil)-1){
		  $value .= $line_graph_kanwil[$i]->kanwil."'";
		}else{
		  $value .= $line_graph_kanwil[$i]->kanwil."','";
		}
	  }
	  echo $value;         
      ?>],
      datasets: [
        {
          label: "Total",
          backgroundColor: "#3e95cd",
          data: [<?php foreach ($line_graph_kanwil as $edc) { ?>
          <?php  echo (int)($edc->sn_total);?>,
          <?php } ?>]
        }, {
          label: "Connected",
          backgroundColor: "#8e5ea2",
          data: [<?php foreach ($line_graph_kanwil as $edc) { ?>
          <?php  echo (int)($edc->sn_connected);?>,
          <?php } ?>]
        }
      ]
    },
    options: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Data EDC per Kantor Wilayah'
      }
    }
});

</script>

<script>
new Chart(document.getElementById("bar-chart-kcp"), {
    type: 'bar',
    data: {
	  labels: [<?php
	  $value = "";
	  for($i=0; $i < count($line_graph_kcp); $i++){
		if($i == 0){
		  $value = "'".$line_graph_kcp[$i]->kcp."','";
		}elseif($i == count($line_graph_kcp)-1){
		  $value .= $line_graph_kcp[$i]->kcp."'";
		}else{
		  $value .= $line_graph_kcp[$i]->kcp."','";
		}
	  }
	  echo $value;         
      ?>],
      datasets: [
        {
          label: "Total",
          backgroundColor: "#3e95cd",
          data: [<?php foreach ($line_graph_kcp as $edc) { ?>
          <?php  echo (int)($edc->sn_total);?>,
          <?php } ?>]
        }, {
          label: "Connected",
          backgroundColor: "#8e5ea2",
          data: [<?php foreach ($line_graph_kcp as $edc) { ?>
          <?php  echo (int)($edc->sn_connected);?>,
          <?php } ?>]
        }
      ]
    },
    options: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Data EDC per KCP'
      }
    }
});

</script>

<script>
new Chart(document.getElementById("bar-chart"), {
    type: 'bar',
    data: {
	  labels: [<?php
	  $value = "";
	  for($i=0; $i < count($line_graph); $i++){
		if($i == 0){
		  $value = "'".$line_graph[$i]->area."','";
		}elseif($i == count($line_graph)-1){
		  $value .= $line_graph[$i]->area."'";
		}else{
		  $value .= $line_graph[$i]->area."','";
		}
	  }
	  echo $value;         
      ?>],
      datasets: [
        {
          label: "Total",
          backgroundColor: "#3e95cd",
          data: [<?php foreach ($line_graph as $edc) { ?>
          <?php  echo (int)($edc->sn_total);?>,
          <?php } ?>]
        }, {
          label: "Connected",
          backgroundColor: "#8e5ea2",
          data: [<?php foreach ($line_graph as $edc) { ?>
          <?php  echo (int)($edc->sn_connected);?>,
          <?php } ?>]
        }
      ]
    },
    options: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Data EDC per Area'
      }
    }
});

</script>
</html>


