<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>
<body id="page-top">

<?php $this->load->view("admin/_partials/navbar.php") ?>


<div id="wrapper">

	<?php $this->load->view("admin/_partials/sidebar.php") ?>

	<div id="content-wrapper">

		<div class="container-fluid">
<?php 
  $color[0] = '"rgba(26, 188, 156, 1)"';
  $color[1] = '"rgba(52, 152, 219, 1)"';
  $color[2] = '"rgba(155, 89, 182, 1)"';
  $color[3] = '"rgba(241, 196, 15, 1)"';
  $color[4] = '"rgba(231, 76, 60, 1)"';
  $color[5] = '"rgba(230, 126, 34, 1)"';
  $color[6] = '"rgba(31, 248, 255, 1)"';
  $color[7] = '"rgba(31, 120, 255, 1)"';
  $color[8] = '"rgba(244, 31, 255, 1)"';
  $color[9] = '"rgba(255, 31, 206, 1)"';
  $color[10] = '"rgba(255, 31, 206, 1)"';
  $color[11] = '"rgba(255, 31, 206, 1)"';
  $color[12] = '"rgba(255, 31, 206, 1)"';
  $color[13] = '"rgba(255, 31, 206, 1)"';
  $color[14] = '"rgba(255, 31, 206, 1)"';
  $color[15] = '"rgba(255, 31, 206, 1)"';

  $bgcolor[0] = '"rgba(26, 188, 156, 0.2)"';
  $bgcolor[1] = '"rgba(52, 152, 219, 0.2)"';
  $bgcolor[2] = '"rgba(155, 89, 182, 0.2)"';
  $bgcolor[3] = '"rgba(241, 196, 15, 0.2)"';
  $bgcolor[4] = '"rgba(231, 76, 60, 0.2)"';
  $bgcolor[5] = '"rgba(230, 126, 34, 0.2)"';
  $bgcolor[6] = '"rgba(31, 248, 255, 0.2)"';
  $bgcolor[7] = '"rgba(31, 120, 255, 0.2)"';
  $bgcolor[8] = '"rgba(244, 31, 255, 0.2)"';
  $bgcolor[9] = '"rgba(255, 31, 206, 0.2)"';
  $bgcolor[10] = '"rgba(255, 31, 206, 0.2)"';
  $bgcolor[11] = '"rgba(255, 31, 206, 0.2)"';
  $bgcolor[12] = '"rgba(255, 31, 206, 0.2)"';
  $bgcolor[13] = '"rgba(255, 31, 206, 0.2)"';
  $bgcolor[14] = '"rgba(255, 31, 206, 0.2)"';
  $bgcolor[15] = '"rgba(255, 31, 206, 0.2)"';
?>             
   

    <div class="card mb-3" style="border: none;">
			<div class="card-body" style="padding:0;" >
         
                  <table class="none" border="1px" style="height: 50px;text-align: center; font-size: 60%; padding: 0px !important;float: left; margin: 5px;" >
                    <tr>
                      <th rowspan="2" style="font-weight: bold; font-size: 170%;">&nbspMerchant&nbsp</th>
                      <th style="color:#080DCC; font-size: 90%;">&nbspConnected&nbsp</th>
                      <th style="color:#000000; font-size: 90%;">&nbspRegistered&nbsp</th>
                    </tr>
                    <tr>
                      <td><span style="color:#080DCC; font-weight: bold; font-size: 160%;">&nbsp<?php echo $merchant_active;?>&nbsp</span></td>
                      <td><span style="color:#000000; font-weight: bold; font-size: 160%;">&nbsp<?php echo $merchant_total;?>&nbsp</span></td>
                    </tr>
                  </table>
            
              
                <table class="none" border="1px" style="height: 50px;text-align: center; font-size: 60%; padding: 0px !important; float: left; margin: 5px;" >
                  <tr>
                    <th rowspan="2" style="font-weight: bold; font-size: 170%;">&nbspEDC&nbsp</th>
                    <th style="color:#080DCC; font-size: 90%;">&nbspConnected&nbsp</th>
                    <th style="color:#000000; font-size: 90%;">&nbspRegistered&nbsp</th>
                  </tr>
                  <tr>
                    <td><span style="color:#080DCC; font-weight: bold; font-size: 160%;">&nbsp<?php echo $terminal_active;?>&nbsp</span></td>
                    <td><span style="color:#000000; font-weight: bold; font-size: 160%;">&nbsp<?php echo $terminal_total;?>&nbsp</span></td>
                  </tr>
                </table>
   
			</div>
    </div>
    
    <div class="card mb-3">
        <div class="card-body" style="padding:6px;" >
                

        
        <form method="POST" action="<?php base_url("admin/data/single_search");?>">
                <div class="row">
                  <div class="col-sm-2">
                    <div class="form-group">
                      <label>Search by</label>
                      <?php
                      $form_field1 = '';
                      echo $form_field1 .= "<select name='filter_type' id='filter_type' class='form-control'>
                      <option value='sn'".($setFilterType == 'sn' ? ' selected' : '' )." >SERIAL NUMBER</option>
                      <option value='spbu'".($setFilterType == 'spbu' ? ' selected' : '' )." >merchant ID</option>
                      <option value='kanwil'".($setFilterType == 'kanwil' ? ' selected' : '' )." >Kantor Wilayah </option>
                      <option value='area'".($setFilterType == 'area' ? ' selected' : '' )." >Area</option>
                      </select>";
                      ?>
                    </div>
                  </div>
                  <div class="col-sm-3">
                      <label>Value</label>
                      <input type="<?php if ($setFilterType == "area"){ echo 'text'; }else{echo 'number';} ?>" 

                      value="<?php if(isset($_POST['search'])){ echo $_POST['serial_number'];}?>" placeholder="e.g 345123" name="serial_number" id="serial_number" class="form-control">
                    </div>
                  <div class="col-sm-2">
                    <div class="form-group">
                      <label>Duration</label>
                      <?php
                      $form_field1 = '';
                      echo $form_field1 .= "<select name='filter_tolerance' id='filter_tolerance' class='form-control'>
                        <option value='1'".($setTolerance == '1' ? ' selected' : '' )." >1 Day</option>
                        <option value='2'".($setTolerance == '2' ? ' selected' : '' )." >2 Days</option>
                        <option value='3'".($setTolerance == '3' ? ' selected' : '' )." >3 Days</option>
                        <option value='5'".($setTolerance == '5' ? ' selected' : '' ).">5 Days</option>
                        <option value='7'".($setTolerance == '7' ? ' selected' : '' ).">7 Days</option>
                        <option value='14'".($setTolerance == '14' ? ' selected' : '' ).">14 Days</option>
                        <option value='30'".($setTolerance == '30' ? ' selected' : '' ).">30 Days</option>
                        <option value='60'".($setTolerance == '60' ? ' selected' : '' ).">60 Days</option>
                        <option value='90'".($setTolerance == '90' ? ' selected' : '' ).">90 Days</option>
                        </select>";
                      ?>
                    </div>
                  </div>

                  <div class="col-sm-2">
                    <div class="form-group">
                      <label>View by</label>
                      <?php
                        $form_field1 = '';
                        echo $form_field1 .= "<select name='filter_time' id='filter_time' class='form-control'>
                          <option value='Hour'".($setTime == 'Hour' ? ' selected' : '' )." >Hour</option>
                          <option value='Day'".($setTime == 'Day' ? ' selected' : '' )." >Day</option>
                          </select>"; 
                      ?>
                    </div>
                  </div>
                <div class="col-sm-1" >
                  <label style="color: #ffffff">Action</label>
                  <button  id="search" name="search" class="btn btn-warning">Search</button>
                </div>
              </div>
            </form>

        </div>
    </div>


    <?php if (isset($_POST['search'])){
    if ($setFilterType == "sn") { ?>
    
  <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-body">
            <div class="tab-content p-0">
              <div class="container">
                <canvas id="<?php if($setTime == 'Hour'){ echo 'demobarHour';}else if($setTime == 'Day'){ echo 'demobarDay';}?>" height="50%"></canvas>
              </div>  
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
      <div class="col-12">
        <div class="card">  
        <div class="card-header">
          <div class="row">
            <?php if(count($single_search) > 0){ ?>
              <?php 
                if (substr($single_search[0]->merchant_code, 1, 1) == '1'){ 
                  $merchant_type = "COCO [1]";
                }elseif (substr($single_search[0]->merchant_code, 1, 1) == '2') {
                  $merchant_type = "DODO [2]";
                } elseif (substr($single_search[0]->merchant_code, 1, 1) == '3') {
                  $merchant_type = "DODO [3]";
                } elseif (substr($single_search[0]->merchant_code, 1, 1) == '4') {
                  $merchant_type = "DODO [4]";
                } else{ 
                  $merchant_type = "X";
                }
              ?>
              <div style="border: 2px solid #EAEAEA;padding: 4px;   vertical-align: middle;">
                <b>SPBU-<?php echo $single_search[0]->merchant_code ?><span style="padding-left: 1em; color: #080DCC"><?php echo $merchant_type ?></span> <span style="padding-left: 1em;"><?php echo "MOR ".substr($single_search[0]->merchant_code, 0, 1) ?></span> <span style="padding-left: 1em; color: #080DCC"><?php echo str_replace("kanwil ", "TR ", $single_search[0]->kanwil); ?></span> <span style="padding-left: 1em;"><?php echo $single_search[0]->area ?></span></b>
              </div>
            <?php } ?>
          </div>
        </div>                  
          <div class="card-body">
            <table id="dataTable" class="table table-bordered table-hover" style="font-size:85%">
              <thead>
                <tr>
                  <!-- <th style="text-align: center;">SPBU NAME</th> -->
                  <!-- <th style="text-align: center;">MOR</th> -->
                  <!-- <th style="text-align: center;">SPBU TYPE</th> -->
                  <th style="text-align: center;">SN</th>
                  <th style="text-align: center;">DEVICE TYPE</th>
                  <th style="text-align: center;">Heartbeat</th>
                </tr>
              </thead>
              <tbody> 
              <?php for ($i=0; $i < count($single_search); $i++) {
                if (substr($single_search[$i]->merchant_code, 1, 1) == '1'){ 
                  $merchant_type = "COCO [1]";
                }elseif (substr($single_search[$i]->merchant_code, 1, 1) == '2') {
                  $merchant_type = "DODO [2]";
                } elseif (substr($single_search[$i]->merchant_code, 1, 1) == '3') {
                  $merchant_type = "DODO [3]";
                } elseif (substr($single_search[$i]->merchant_code, 1, 1) == '4') {
                  $merchant_type = "DODO [4]";
                } else{ 
                  $merchant_type = "X";
                }?>
                <tr>
                  <!-- <td style="text-align: center;"><?php echo $single_search[$i]->merchant_name;?></td>
                  <td style="text-align: center;"><?php echo "MOR ".substr($single_search[$i]->merchant_code, 0, 1);?></td>
                  <td style="text-align: center;"><?php echo $merchant_type; ?></td> -->
                  <td style="text-align: center;"><?php echo $single_search[$i]->sn?></td>
                  <td style="text-align: center;"><?php echo $single_search[$i]->device_type?></td>
                  <td style="text-align: center;"><?php echo $single_search[$i]->created_date?></td>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>      
    </div>
    <?php }elseif (( $setFilterType == "kanwil" || $setFilterType == "area") && $serial_number != ""){ ?> 
    <div class="row">
      <div class="col-12">
        <div class="card">          
          <div class="card-body">
            <div class="tab-content p-0">
              <div class="container">
                <canvas id="<?php 
                  if($setFilterType == "mor"){
                      if($setTime == 'Hour'){ echo 'demobarHourMor';}else if($setTime == 'Day'){ echo 'demobarDayMor';}
                    }elseif($setFilterType == "kanwil"){
                        if($serial_number== ""){
                          echo 'barkanwilarea';
                        }else{
                          if($setTime == 'Hour'){ echo 'demobarHourkanwil';}else if($setTime == 'Day'){ echo 'demobarDaykanwil';}
                        }
                    }else{
                      if($serial_number== ""){ 
                          echo 'barkanwilarea';
                        }else{
                          if($setTime == 'Hour'){ echo 'demobarHourarea';}else if($setTime == 'Day'){ echo 'demobarDayarea';}
                        }
                    }
                  ?>" height="50%"></canvas>
              </div>  
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
      <div class="col-12">
        <div class="card">          
          <div class="card-body">
            <table id="dataTable" class="table table-bordered table-hover" style="font-size:85%">
              <thead>
                <tr>
                  <th style="text-align: center;"><?php 
                        if ($setFilterType == "mor"){ echo 'MOR';}elseif ($setFilterType == "kanwil"){ echo 'kanwil';}else{echo 'area';}?>
                  </th>
                  <th style="text-align: center; color: rgb(0, 126, 255); font-weight: bold;">Connected Merchant</th>
                  <th style="text-align: center; color: rgb(0, 126, 255); font-weight: bold;">Connected EDC</th>
                  <?php if($serial_number != "" ) {?>
                  <th style="text-align: center;">Date</th>
                  <?php } ?>
                </tr>
              </thead>
              <tbody> 
              <?php for ($i=0; $i < count($line_graph); $i++) { ?>
                <tr>
                  <td style="text-align: center;"><?php 
                      if ($setFilterType == "mor"){
                      echo "MOR ".$line_graph[$i]->mor;
                      }elseif ($setFilterType == "kanwil"){
                        echo $line_graph[$i]->kanwil;
                      }else{
                        echo $line_graph[$i]->area;
                      } ?>
                  </td>
                  <td style="text-align: center; color: rgb(0, 126, 255); font-weight: bold;"><?php echo $line_graph[$i]->merchant_connected; ?></td>
                  <td style="text-align: center; color: rgb(0, 126, 255); font-weight: bold;"><?php echo $line_graph[$i]->sn_connected; ?></td>
                  <?php if($serial_number != "") {?>
                    <td style="text-align: center;"><?php echo $line_graph[$i]->created_date; ?></td>
                  <?php } ?>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>      
    </div> 
    <?php }elseif (($setFilterType == "kanwil" || $setFilterType == "area") && $serial_number == ""){ ?> 
    <div class="row">
      <div class="col-12">
        <div class="card">          
          <div class="card-body">
            <div class="tab-content p-0">
              <div class="container">
                <canvas id="<?php echo 'barkanwilarea'; ?>" height="70%"></canvas>
              </div>  
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
      <div class="col-12">
        <div class="card">          
          <div class="card-body">
            <table id="dataTable" class="table table-bordered table-hover" style="font-size:85%">
              <thead>
                <tr>
                  <th style="text-align: center;"><?php 
                        if ($setFilterType == "mor"){ echo 'MOR';}elseif ($setFilterType == "kanwil"){ echo 'kanwil';}else{echo 'area';}?>
                  </th>
                  <th style="text-align: center; color: rgb(0, 126, 255); font-weight: bold;">Connected Merchant</th>
                  <th style="text-align: center; color: rgb(0, 126, 255); font-weight: bold;">Connected EDC</th>
                </tr>
              </thead>
              <tbody> 
              <?php for ($i=0; $i < count($line_graphs); $i++) { ?>
                <tr>
                  <td style="text-align: center;"><?php 
                      if ($setFilterType == "mor"){
                      echo "MOR ".$line_graphs[$i]->mor;
                      }elseif ($setFilterType == "kanwil"){
                        echo $line_graphs[$i]->kanwil;
                      }else{
                        echo $line_graphs[$i]->area;
                      } ?>
                  </td>
                  <td style="text-align: center; color: rgb(0, 126, 255); font-weight: bold;"><?php echo $line_graphs[$i]->merchant_connected; ?></td>
                  <td style="text-align: center; color: rgb(0, 126, 255); font-weight: bold;"><?php echo $line_graphs[$i]->sn_connected; ?></td>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>      
    </div> 
    <?php }else{ ?>      
      <div class="row">
          <div class="col-12">
            <div class="card">          
              <div class="card-body">
                <div class="tab-content p-0">
                  <div class="container">
                    <canvas id="<?php if($setTime == 'Hour'){ echo 'CanvasLineSnHour';}else if($setTime == 'Day'){ echo 'CanvasLineSnDay';}?>" height="<?php if($setTime == 'Hour'){if($setTolerance >= "14"){echo "80%";}else{echo "70%";}}else if($setTime == 'Day'){if($setTolerance >= "14"){echo "70%";}else{echo "50%";}}?>" legend="true" series="series" options="{showTooltips: false}" colours="[ { fillColor: '#ffff00' }, { fillColor: '#0066ff' } ]"></canvas>              
                  </div>    
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
      <div class="col-12">
        <div class="card">          
          <div class="card-body">
            <table id="dataTable" class="table table-bordered table-hover" style="font-size:85%">
              <thead>
                <tr>
                  <th style="text-align: center;">Merchant Name</th>
                  
                  <th style="text-align: center;">Merchant Type</th>
                  <th style="text-align: center;">SN</th>
                  <th style="text-align: center;">DEVICE TYPE</th>
                  <th style="text-align: center;">TIME</th>
                </tr>
              </thead>
              <tbody> 
              <?php for ($i=0; $i < count($single_search); $i++) {
                if (substr($single_search[$i]->merchant_code, 1, 1) == '1'){ 
                  $merchant_type = "COCO [1]";
                }elseif (substr($single_search[$i]->merchant_code, 1, 1) == '2') {
                  $merchant_type = "DODO [2]";
                } elseif (substr($single_search[$i]->merchant_code, 1, 1) == '3') {
                  $merchant_type = "DODO [3]";
                } elseif (substr($single_search[$i]->merchant_code, 1, 1) == '4') {
                  $merchant_type = "DODO [4]";
                } ?>
                <tr>
                  <td style="text-align: center;"><?php echo $single_search[$i]->merchant_name;?></td>
                  
                  <td style="text-align: center;"><?php echo $merchant_type; ?></td>
                  <td style="text-align: center;"><?php echo $single_search[$i]->sn?></td>
                  <td style="text-align: center;"><?php echo $single_search[$i]->device_type?></td>
                  <td style="text-align: center;"><?php echo $single_search[$i]->created_date?></td>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>      
    </div>  

  <?php 
  if (isset($_POST['search']) && $_POST['serial_number'] != NULL){ 
    if ((strlen($_POST['serial_number']) <= 10) && $setTime == "Day") {
      // for ($i=0; $i < count($result_search); $i++) { 
      //   for ($j=0; $j < count($result_search[$i]); $j++) { 
      //     echo $result_search[$i][$j]->myData.", ";
      //   }
      //   echo "<br>";
      // }

      echo "<br>";
      for ($z=0; $z < count($result_search); $z++) {
        $dateStatus[] = array();    
        $valueees[] = array();
        $currentDateTime = date('Y-m-d');
        $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -$setTolerance day")); 
        $value = ""; 
        for ($i=0; $i <= $setTolerance; $i++){
          $check = false;
          for ($j=0; $j < count($result_search[$z]); $j++) {
            if ($result_search[$z][$j]->myData === $currentDateTime) {
              $dateStatus[$z][$i] = "1";
              $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day"));

              $check = true;
              break;
            }  
          }
          if (!$check) {
              $dateStatus[$z][$i] = "0"; 
              $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day")); 
          }
        }
        for ($b=0; $b <= $setTolerance; $b++){
          $value .= $dateStatus[$z][$b].",";
        } 
        $value = substr_replace($value ,"",-1);
        $valueees[$z] = $value;
        // echo $value;
        // echo "<br>";
      }
    }else{

      for ($z=0; $z < count($result_search); $z++) {
        $dateStatus[][] = array();    
        $valueees[] = array();
        $nowDateTime = null;
        $dateNow = null;
        $currentDateTime = null;
        $nowDateTime = date('Y-m-d 23:00:00');
        $dateNow=date_create($nowDateTime);
        date_add($dateNow,date_interval_create_from_date_string("-".($setTolerance+1)." day"));
        $currentDateTime = date_format($dateNow,"Y-m-d H");
        $value = ""; 
        $noArr = 1;

        for ($i=0; $i <= $setTolerance; $i++){
          for ($h=1; $h <= 24; $h++) {        
            $check = false;  
            for ($j=0; $j < count($result_search[$z]); $j++) {
              if ($result_search[$z][$j]->myData === $currentDateTime) {
                $dateStatus[$z][$noArr] = "1";
                date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
                $currentDateTime = date_format($dateNow,"Y-m-d H");
                $check = true;
                break;
              }  
            }
            if (!$check) {
              $dateStatus[$z][$noArr] = "0";
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
            }
            $noArr++;
          }
        }
        for ($b=1; $b <= (1+$setTolerance)*24; $b++){
          $value .= $dateStatus[$z][$b].",";
        } 
        $value = substr_replace($value ,"",-1);
        $valueees[$z] = $value;
        // echo $value;
        // echo "<br>";
      }
      // echo $noArr;
      // echo "<br>";
      // echo (1+$setTolerance)*24;
    }
  }
    ?>
    <?php } } ?>              
  </div>



    </div>
		<!-- /.container-fluid -->

		<!-- Sticky Footer -->
		<?php $this->load->view("admin/_partials/footer.php") ?>

	</div>
	<!-- /.content-wrapper -->

</div>
<!-- /#wrapper -->


<?php $this->load->view("admin/_partials/scrolltop.php") ?>
<?php $this->load->view("admin/_partials/modal.php") ?>
<?php $this->load->view("admin/_partials/js.php") ?>
    
</body>

<script type="text/javascript">
  $( document ).ready(function() {
    $('#filter_type').on('change', function() {
          console.log("value: "+this.value);
        if(this.value === "area"){
          $("#serial_number").prop('type', 'text');
        }else{
          $("#serial_number").prop('type', 'number');
        }
      });
  });
</script>

<?php if ($setFilterType != "mor" && $setFilterType != "kanwil" && $setFilterType != "area"){ ?> 
<script  type="text/javascript">
  var ctx = document.getElementById("demobarHour").getContext("2d");
  var data = {
    labels: [<?php
      $nowDateTime = null;
      $dateNow = null;
      $currentDateTime = null;
      $nowDateTime = date('Y-m-d 23:00:00');
      $dateNow=date_create($nowDateTime);
      date_add($dateNow,date_interval_create_from_date_string("-".($setTolerance+1)." day"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");
      $value = ""; 
      $noArr = 1;
      for ($i=0; $i <= $setTolerance; $i++){
                      for ($h=1; $h <= 24; $h++) {        
              $value .= "'$currentDateTime',";
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
              $noArr++;
        }
      }      
      $value .= "'$currentDateTime',";
      date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");
      $noArr++;
      $value = substr_replace($value ,"",-1); 
      echo $value;
    ?>],
    datasets: [
    {
      label: "SN : <?php if (isset($_POST['search'])) { echo $_POST['serial_number'];}?>",
      fill: false,
      backgroundColor: "rgba(59, 100, 222, 1)",
      borderColor: "rgba(59, 100, 222, 1)",
      pointHoverBackgroundColor: "rgba(59, 100, 222, 1)",
      pointHoverBorderColor: "rgba(59, 100, 222, 1)",
      data: [<?php
      $nowDateTime = null;
      $dateNow = null;
      $currentDateTime = null;
      $nowDateTime = date('Y-m-d 23:00:00');
      $dateNow=date_create($nowDateTime);
      date_add($dateNow,date_interval_create_from_date_string("-".($setTolerance+1)." day"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");

      $dateStatus[] = array();
      $value = ""; 
      $noArr = 1;
      for ($i=0; $i <= $setTolerance; $i++){
        for ($h=1; $h <= 24; $h++) {        
        $check = false;  
          for ($j=0; $j < count($line_graph); $j++) {
            if ($line_graph[$j]->myData === $currentDateTime) {
              $dateStatus[$noArr] = "1";
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
              $check = true;
              break;
            }
          }
          if (!$check) {
              $dateStatus[$noArr] = "0";
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
          }
          $noArr++;
        }
      }
      $value = "";
      for ($z=1; $z <= (1+$setTolerance)*24; $z++){
        $value .= $dateStatus[$z].",";
      }
      $value = substr_replace($value ,"",-1);
      echo $value; 
    ?>]
    }]
  };

  var myBarChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
    barValueSpacing: 20,
    legend : {
      display : true,
      position : "bottom"
    },
    elements: { 
      point: { 
        radius: 1 
      } 
    },
    scales: {
      yAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        },
        ticks: {
          min: 0, 
          max: 1, 
          stepSize: 1,
          pointRadius: 0,
        }
      }],
      xAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        }
      }]
    }
  }
});
</script>
            
<script  type="text/javascript">
  var ctx = document.getElementById("demobarDay").getContext("2d");
  var data = {
    labels: [<?php 
      $currentDateTime = date('Y-m-d');
      $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -$setTolerance day")); 
      $dateStatus[] = array();    
      $value = ""; 

      for ($i=0; $i <= $setTolerance; $i++){
        $check = false;
        for ($j=0; $j < count($line_graph); $j++) {
          if ($line_graph[$j]->myData === $currentDateTime) {
            $dateStatus[$i] = "1";
            $value .= "'$currentDateTime',";
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day"));

            $check = true;
            break;
          }  
        }
        if (!$check) {
            $dateStatus[$i] = "0";
            $value .= "'$currentDateTime',"; 
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day")); 
        }
      }
      $value = substr_replace($value ,"",-1); echo $value;
    ?>],
    datasets: [
    {
      label: "SN : <?php if (isset($_POST['search'])) { echo $_POST['serial_number'];}?>",
      fill: false,
      backgroundColor: "rgba(59, 100, 222, 1)",
      borderColor: "rgba(59, 100, 222, 1)",
      pointHoverBackgroundColor: "rgba(59, 100, 222, 1)",
      pointHoverBorderColor: "rgba(59, 100, 222, 1)",
      data: [<?php 
      $currentDateTime = date('Y-m-d');
      $dateStatus[] = array();    
      $value = ""; 

      for ($i=0; $i <= $setTolerance; $i++){
        $check = false;
        for ($j=0; $j < count($line_graph); $j++) {
          if ($line_graph[$j]->myData === $currentDateTime) {
            $dateStatus[$i] = "1";
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -1 day"));

            $check = true;
            break;
          }  
        }
        if (!$check) {
            $dateStatus[$i] = "0"; 
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -1 day")); 
        }
      }
      for ($z=$setTolerance; $z >= 0; $z--){
        $value .= $dateStatus[$z].",";
      }
      $value = substr_replace($value ,"",-1); 
      echo $value;
      ?>]
    }]
  };

  var myBarChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
    barValueSpacing: 20,
    legend : {
      display : true,
      position : "bottom"
    },
    elements: { 
      point: { 
        radius: 3 
      } 
    },
    scales: {
      yAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        },
        ticks: {
          min: 0, 
          max: 1, 
          stepSize: 1,
        }
      }],
      xAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        }
      }]
    }
  }
});
</script>

<script  type="text/javascript">
  var ctx = document.getElementById("CanvasLineSnDay").getContext("2d");
  var data = {
    labels: [<?php 
      $currentDateTime = date('Y-m-d');
      $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -$setTolerance day")); 
      $dateStatus[] = array();    
      $value = ""; 

      for ($i=0; $i <= $setTolerance; $i++){
        $check = false;
        for ($j=0; $j < count($line_graph); $j++) {
          if ($line_graph[$j]->myData === $currentDateTime) {
            $dateStatus[$i] = "1";
            $value .= "'$currentDateTime',";
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day"));

            $check = true;
            break;
          }  
        }
        if (!$check) {
            $dateStatus[$i] = "0";
            $value .= "'$currentDateTime',"; 
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day")); 
        }
      }
      $value = substr_replace($value ,"",-1); echo $value;
    ?>],
    datasets: [
    <?php for ($i=0; $i < count($resvalue_search); $i++) { ?>
    {
      label: "SN : <?php if (isset($_POST['search'])) { echo $resvalue_search[$i]->sn;}?>",
      fill: true,
      lineTension: 0,
      backgroundColor: <?php echo $bgcolor[$i];?>,
      borderColor: <?php echo $color[$i];?>,
      borderWidth: 2,
      pointHoverBackgroundColor: <?php echo $color[$i];?>,
      pointHoverBorderColor: <?php echo $color[$i];?>,
      data: [<?php echo $valueees[$i]?>]
    },
    <?php } ?>]
  };

  var myBarChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
	    barValueSpacing: 20,
	    legend : {
	      display : true,
	      position : "bottom"
	    },
	    elements: { 
	      point: { 
	        radius: 2,
	        tension: 0.5,
	      } 
	    },
	    scales: {
	      yAxes: [{
	        gridLines: {
	          color: "rgba(0, 0, 0, 0)",
	        },
	        ticks: {
	          min: 0, 
	          max: 1, 
	          stepSize: 1,
	          barPercentage: 0.9,
	          categoryPercentage: 0.55
	        }
	      }],
	      xAxes: [{
	        gridLines: {
	          color: "rgba(0, 0, 0, 0)",
	        }
	      }]
	    },
		plugins: {
	      	zoom: {
	          pan: {
	            enabled: true,
	            mode: 'xy'
	          },
	          zoom: {
	            enabled: true,
	            mode: 'xy'
	        }
	      }
	    }
	}
});
</script>

<script  type="text/javascript">
  var ctx = document.getElementById("CanvasLineSnHour").getContext("2d");
  var data = {
    labels: [<?php
      $nowDateTime = null;
      $dateNow = null;
      $currentDateTime = null;
      $nowDateTime = date('Y-m-d 23:00:00');
      $dateNow=date_create($nowDateTime);
      date_add($dateNow,date_interval_create_from_date_string("-".($setTolerance+1)." day"));
      $currentDateTime = date_format($dateNow,"Y-m-d H:00:00");
      $value = ""; 
      $noArr = 1;
      for ($i=0; $i <= $setTolerance; $i++){
        for ($h=1; $h <= 24; $h++) {        
          $value .= "'$currentDateTime',";
          date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
          $currentDateTime = date_format($dateNow,"Y-m-d H:00:00");
          $noArr++;
        }
      }      
      $value .= "'$currentDateTime',";
      date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
      $currentDateTime = date_format($dateNow,"Y-m-d H:00:00");
      $noArr++;
      $value = substr_replace($value ,"",-1); 
      echo $value;
    ?>],
    datasets: [
    <?php for ($i=0; $i < count($resvalue_search); $i++) { ?>
    {
      label: "SN : <?php if (isset($_POST['search'])) { echo $resvalue_search[$i]->sn;}?>",
      fill: true,
      lineTension: 0,
      backgroundColor: <?php echo $bgcolor[$i];?>,
      borderColor: <?php echo $color[$i];?>,
      borderWidth: 2,
      pointHoverBackgroundColor: <?php echo $color[$i];?>,
      pointHoverBorderColor: <?php echo $color[$i];?>,
      data: [<?php echo $valueees[$i]?>]
    },
    <?php } ?>]
  };

  var myBarChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
    barValueSpacing: 20,
    legend : {
      display : true,
      position : "bottom"
    },
    elements: { 
      point: { 
        radius: 1 
      } 
    },
    scales: {
      yAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        },
        ticks: {
          min: 0, 
          max: 1, 
          stepSize: 1,
          pointRadius: 0,
        }
      }],
      xAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        }
      }]
    }
  }
});
</script>
<?php } ?>

<script  type="text/javascript">
  var ctx = document.getElementById("demobarDayMor").getContext("2d");
  var data = {
    labels: [<?php 
      $currentDateTime = date('Y-m-d');
      $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -$setTolerance day")); 
      $dateStatus[] = array();    
      $value = ""; 

      for ($i=0; $i <= $setTolerance; $i++){
        $check = false;
        for ($j=0; $j < count($line_graph); $j++) {
          if ($line_graph[$j]->created_date === $currentDateTime) {
            $dateStatus[$i] = $line_graph[$j]->merchant_connected;
            $value .= "'$currentDateTime',";
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day"));

            $check = true;
            break;
          }  
        }
        if (!$check) {
            $dateStatus[$i] = "0";
            $value .= "'$currentDateTime',"; 
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day")); 
        }
      }
      $value = substr_replace($value ,"",-1); echo $value;
    ?>],
    datasets: [
    {
      label: "MOR : <?php if (isset($_POST['search'])) { echo $_POST['serial_number'];}?>",
      fill: false,
      backgroundColor: "rgba(59, 100, 222, 1)",
      borderColor: "rgba(59, 100, 222, 1)",
      pointHoverBackgroundColor: "rgba(59, 100, 222, 1)",
      pointHoverBorderColor: "rgba(59, 100, 222, 1)",
      data: [<?php 
      $currentDateTime = date('Y-m-d');
      $dateStatus[] = array();    
      $value = ""; 

      for ($i=0; $i <= $setTolerance; $i++){
        $check = false;
        for ($j=0; $j < count($line_graph); $j++) {
          if ($line_graph[$j]->created_date === $currentDateTime) {
            $dateStatus[$i] = $line_graph[$j]->merchant_connected;
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -1 day"));

            $check = true;
            break;
          }  
        }
        if (!$check) {
            $dateStatus[$i] = "0"; 
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -1 day")); 
        }
      }
      for ($z=$setTolerance; $z >= 0; $z--){
        $value .= $dateStatus[$z].",";
      }
      $value = substr_replace($value ,"",-1); 
      echo $value;
      ?>]
    }]
  };

  var myBarChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
    barValueSpacing: 20,
    legend : {
      display : true,
      position : "bottom"
    },
    elements: { 
      point: { 
        radius: 3 
      } 
    },
    scales: {
      yAxes: [{
        gridLines: {
          color: "#ff0000",
        },
        ticks: {
          min: 0,
        }
      }],
      xAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        }
      }]
    }
  }
});
</script>


<script  type="text/javascript">
  var ctx = document.getElementById("demobarHourMor").getContext("2d");
  var data = {
    labels: [<?php
      $nowDateTime = null;
      $dateNow = null;
      $currentDateTime = null;
      $nowDateTime = date('Y-m-d 23:00:00');
      $dateNow=date_create($nowDateTime);
      date_add($dateNow,date_interval_create_from_date_string("-".($setTolerance+1)." day"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");
      $value = ""; 
      $noArr = 1;
      for ($i=0; $i <= $setTolerance; $i++){
                      for ($h=1; $h <= 24; $h++) {        
              $value .= "'$currentDateTime',";
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
              $noArr++;
        }
      }      
      $value .= "'$currentDateTime',";
      date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");
      $noArr++;
      $value = substr_replace($value ,"",-1); 
      echo $value;
    ?>],
    datasets: [
    {
      label: "MOR : <?php if (isset($_POST['search'])) { echo $_POST['serial_number'];}?>",
      fill: false,
      backgroundColor: "rgba(59, 100, 222, 1)",
      borderColor: "rgba(59, 100, 222, 1)",
      pointHoverBackgroundColor: "rgba(59, 100, 222, 1)",
      pointHoverBorderColor: "rgba(59, 100, 222, 1)",
      data: [<?php
      $nowDateTime = null;
      $dateNow = null;
      $currentDateTime = null;
      $nowDateTime = date('Y-m-d 23:00:00');
      $dateNow=date_create($nowDateTime);
      date_add($dateNow,date_interval_create_from_date_string("-".($setTolerance+1)." day"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");

      $dateStatus[] = array();
      $value = ""; 
      $noArr = 1;
      for ($i=0; $i <= $setTolerance; $i++){
        for ($h=1; $h <= 24; $h++) {        
        $check = false;  
          for ($j=0; $j < count($line_graph); $j++) {
            if ($line_graph[$j]->created_date === $currentDateTime) {
              $dateStatus[$noArr] = $line_graph[$j]->merchant_connected;
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
              $check = true;
              break;
            }
          }
          if (!$check) {
              $dateStatus[$noArr] = "0";
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
          }
          $noArr++;
        }
      }
      $value = "";
      for ($z=1; $z <= (1+$setTolerance)*24; $z++){
        $value .= $dateStatus[$z].",";
      }
      $value = substr_replace($value ,"",-1);
      echo $value; 
    ?>]
    }]
  };

  var myBarChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
    barValueSpacing: 20,
    legend : {
      display : true,
      position : "bottom"
    },
    elements: { 
      point: { 
        radius: 1 
      } 
    },
    scales: {
      yAxes: [{
        gridLines: {
          color: "#ff0000",
        },
        ticks: {
          min: 0, 
          pointRadius: 0,
        }
      }],
      xAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        }
      }]
    }
  }
});
</script>


<script  type="text/javascript">
  var ctx = document.getElementById("demobarDaykanwil").getContext("2d");
  var data = {
    labels: [<?php 
      $currentDateTime = date('Y-m-d');
      $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -$setTolerance day")); 
      $dateStatus[] = array();    
      $value = ""; 

      for ($i=0; $i <= $setTolerance; $i++){
        $check = false;
        for ($j=0; $j < count($line_graph); $j++) {
          if ($line_graph[$j]->created_date === $currentDateTime) {
            $dateStatus[$i] = $line_graph[$j]->merchant_connected;
            $value .= "'$currentDateTime',";
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day"));

            $check = true;
            break;
          }  
        }
        if (!$check) {
            $dateStatus[$i] = "0";
            $value .= "'$currentDateTime',"; 
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day")); 
        }
      }
      $value = substr_replace($value ,"",-1); echo $value;
    ?>],
    datasets: [
    {
      label: "kanwil : <?php if (isset($_POST['search'])) { echo $_POST['serial_number'];}?>",
      fill: false,
      backgroundColor: "rgba(59, 100, 222, 1)",
      borderColor: "rgba(59, 100, 222, 1)",
      pointHoverBackgroundColor: "rgba(59, 100, 222, 1)",
      pointHoverBorderColor: "rgba(59, 100, 222, 1)",
      data: [<?php 
      $currentDateTime = date('Y-m-d');
      $dateStatus[] = array();    
      $value = ""; 

      for ($i=0; $i <= $setTolerance; $i++){
        $check = false;
        for ($j=0; $j < count($line_graph); $j++) {
          if ($line_graph[$j]->created_date === $currentDateTime) {
            $dateStatus[$i] = $line_graph[$j]->merchant_connected;
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -1 day"));

            $check = true;
            break;
          }  
        }
        if (!$check) {
            $dateStatus[$i] = "0"; 
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -1 day")); 
        }
      }
      for ($z=$setTolerance; $z >= 0; $z--){
        $value .= $dateStatus[$z].",";
      }
      $value = substr_replace($value ,"",-1); 
      echo $value;
      ?>]
    }]
  };

  var myBarChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
    barValueSpacing: 20,
    legend : {
      display : true,
      position : "bottom"
    },
    elements: { 
      point: { 
        radius: 3 
      } 
    },
    scales: {
      yAxes: [{
        gridLines: {
          color: "#ff0000",
        },
        ticks: {
          min: 0,
        }
      }],
      xAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        }
      }]
    }
  }
});
</script>


<script  type="text/javascript">
  var ctx = document.getElementById("demobarHourkanwil").getContext("2d");
  var data = {
    labels: [<?php
      $nowDateTime = null;
      $dateNow = null;
      $currentDateTime = null;
      $nowDateTime = date('Y-m-d 23:00:00');
      $dateNow=date_create($nowDateTime);
      date_add($dateNow,date_interval_create_from_date_string("-".($setTolerance+1)." day"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");
      $value = ""; 
      $noArr = 1;
      for ($i=0; $i <= $setTolerance; $i++){
                      for ($h=1; $h <= 24; $h++) {        
              $value .= "'$currentDateTime',";
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
              $noArr++;
        }
      }      
      $value .= "'$currentDateTime',";
      date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");
      $noArr++;
      $value = substr_replace($value ,"",-1); 
      echo $value;
    ?>],
    datasets: [
    {
      label: "kanwil : <?php if (isset($_POST['search'])) { echo $_POST['serial_number'];}?>",
      fill: false,
      backgroundColor: "rgba(59, 100, 222, 1)",
      borderColor: "rgba(59, 100, 222, 1)",
      pointHoverBackgroundColor: "rgba(59, 100, 222, 1)",
      pointHoverBorderColor: "rgba(59, 100, 222, 1)",
      data: [<?php
      $nowDateTime = null;
      $dateNow = null;
      $currentDateTime = null;
      $nowDateTime = date('Y-m-d 23:00:00');
      $dateNow=date_create($nowDateTime);
      date_add($dateNow,date_interval_create_from_date_string("-".($setTolerance+1)." day"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");

      $dateStatus[] = array();
      $value = ""; 
      $noArr = 1;
      for ($i=0; $i <= $setTolerance; $i++){
        for ($h=1; $h <= 24; $h++) {        
        $check = false;  
          for ($j=0; $j < count($line_graph); $j++) {
            if ($line_graph[$j]->created_date === $currentDateTime) {
              $dateStatus[$noArr] = $line_graph[$j]->merchant_connected;
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
              $check = true;
              break;
            }
          }
          if (!$check) {
              $dateStatus[$noArr] = "0";
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
          }
          $noArr++;
        }
      }
      $value = "";
      for ($z=1; $z <= (1+$setTolerance)*24; $z++){
        $value .= $dateStatus[$z].",";
      }
      $value = substr_replace($value ,"",-1);
      echo $value; 
    ?>]
    }]
  };

  var myBarChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
    barValueSpacing: 20,
    legend : {
      display : true,
      position : "bottom"
    },
    elements: { 
      point: { 
        radius: 1 
      } 
    },
    scales: {
      yAxes: [{
        gridLines: {
          color: "#ff0000",
        },
        ticks: {
          min: 0, 
          pointRadius: 0,
        }
      }],
      xAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        }
      }]
    }
  }
});
</script>


<script  type="text/javascript">
  var ctx = document.getElementById("demobarDayarea").getContext("2d");
  var data = {
    labels: [<?php 
      $currentDateTime = date('Y-m-d');
      $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -$setTolerance day")); 
      $dateStatus[] = array();    
      $value = ""; 

      for ($i=0; $i <= $setTolerance; $i++){
        $check = false;
        for ($j=0; $j < count($line_graph); $j++) {
          if ($line_graph[$j]->created_date === $currentDateTime) {
            $dateStatus[$i] = $line_graph[$j]->merchant_connected;
            $value .= "'$currentDateTime',";
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day"));

            $check = true;
            break;
          }  
        }
        if (!$check) {
            $dateStatus[$i] = "0";
            $value .= "'$currentDateTime',"; 
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime +1 day")); 
        }
      }
      $value = substr_replace($value ,"",-1); echo $value;
    ?>],
    datasets: [
    {
      label: "area : <?php if (isset($_POST['search'])) { echo $_POST['serial_number'];}?>",
      fill: false,
      backgroundColor: "rgba(59, 100, 222, 1)",
      borderColor: "rgba(59, 100, 222, 1)",
      pointHoverBackgroundColor: "rgba(59, 100, 222, 1)",
      pointHoverBorderColor: "rgba(59, 100, 222, 1)",
      data: [<?php 
      $currentDateTime = date('Y-m-d');
      $dateStatus[] = array();    
      $value = ""; 

      for ($i=0; $i <= $setTolerance; $i++){
        $check = false;
        for ($j=0; $j < count($line_graph); $j++) {
          if ($line_graph[$j]->created_date === $currentDateTime) {
            $dateStatus[$i] = $line_graph[$j]->merchant_connected;
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -1 day"));

            $check = true;
            break;
          }  
        }
        if (!$check) {
            $dateStatus[$i] = "0"; 
            $currentDateTime = strftime("%Y-%m-%d", strtotime("$currentDateTime -1 day")); 
        }
      }
      for ($z=$setTolerance; $z >= 0; $z--){
        $value .= $dateStatus[$z].",";
      }
      $value = substr_replace($value ,"",-1); 
      echo $value;
      ?>]
    }]
  };

  var myBarChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
    barValueSpacing: 20,
    legend : {
      display : true,
      position : "bottom"
    },
    elements: { 
      point: { 
        radius: 3 
      } 
    },
    scales: {
      yAxes: [{
        gridLines: {
          color: "#ff0000",
        },
        ticks: {
          min: 0,
        }
      }],
      xAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        }
      }]
    }
  }
});
</script>


<script  type="text/javascript">
  var ctx = document.getElementById("demobarHourarea").getContext("2d");
  var data = {
    labels: [<?php
      $nowDateTime = null;
      $dateNow = null;
      $currentDateTime = null;
      $nowDateTime = date('Y-m-d 23:00:00');
      $dateNow=date_create($nowDateTime);
      date_add($dateNow,date_interval_create_from_date_string("-".($setTolerance+1)." day"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");
      $value = ""; 
      $noArr = 1;
      for ($i=0; $i <= $setTolerance; $i++){
                      for ($h=1; $h <= 24; $h++) {        
              $value .= "'$currentDateTime',";
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
              $noArr++;
        }
      }      
      $value .= "'$currentDateTime',";
      date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");
      $noArr++;
      $value = substr_replace($value ,"",-1); 
      echo $value;
    ?>],
    datasets: [
    {
      label: "area : <?php if (isset($_POST['search'])) { echo $_POST['serial_number'];}?>",
      fill: false,
      backgroundColor: "rgba(59, 100, 222, 1)",
      borderColor: "rgba(59, 100, 222, 1)",
      pointHoverBackgroundColor: "rgba(59, 100, 222, 1)",
      pointHoverBorderColor: "rgba(59, 100, 222, 1)",
      data: [<?php
      $nowDateTime = null;
      $dateNow = null;
      $currentDateTime = null;
      $nowDateTime = date('Y-m-d 23:00:00');
      $dateNow=date_create($nowDateTime);
      date_add($dateNow,date_interval_create_from_date_string("-".($setTolerance+1)." day"));
      $currentDateTime = date_format($dateNow,"Y-m-d H");

      $dateStatus[] = array();
      $value = ""; 
      $noArr = 1;
      for ($i=0; $i <= $setTolerance; $i++){
        for ($h=1; $h <= 24; $h++) {        
        $check = false;  
          for ($j=0; $j < count($line_graph); $j++) {
            if ($line_graph[$j]->created_date === $currentDateTime) {
              $dateStatus[$noArr] = $line_graph[$j]->merchant_connected;
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
              $check = true;
              break;
            }
          }
          if (!$check) {
              $dateStatus[$noArr] = "0";
              date_add($dateNow,date_interval_create_from_date_string("+1 hour"));
              $currentDateTime = date_format($dateNow,"Y-m-d H");
          }
          $noArr++;
        }
      }
      $value = "";
      for ($z=1; $z <= (1+$setTolerance)*24; $z++){
        $value .= $dateStatus[$z].",";
      }
      $value = substr_replace($value ,"",-1);
      echo $value; 
    ?>]
    }]
  };

  var myBarChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
    barValueSpacing: 20,
    legend : {
      display : true,
      position : "bottom"
    },
    elements: { 
      point: { 
        radius: 1 
      } 
    },
    scales: {
      yAxes: [{
        gridLines: {
          color: "#ff0000",
        },
        ticks: {
          min: 0, 
          pointRadius: 0,
        }
      }],
      xAxes: [{
        gridLines: {
          color: "rgba(0, 0, 0, 0)",
        }
      }]
    }
  }
});
</script>

 <script>
  console.log("<?php 
                $value = "";
                if($setFilterType == "kanwil"){
                  for($i=0; $i < count($line_graphs); $i++){
                    if($i == 0){
                      $value = "'".$line_graphs[$i]->kanwil."','";
                    }elseif($i == count($line_graphs)-1){
                      $value .= $line_graphs[$i]->kanwil."'";
                    }else{
                      $value .= $line_graphs[$i]->kanwil."','";
                    }
                  }
                }else{
                  for($i=0; $i < count($line_graphs); $i++){
                    if($i == 0){
                      $value = "'".$line_graphs[$i]->area."','";
                    }elseif($i == count($line_graphs)-1){
                      $value .= $line_graphs[$i]->area."'";
                    }else{
                      $value .= $line_graphs[$i]->area."','";
                    }
                  }
                }
                
                echo $value;
              ?>");
      var ctx = document.getElementById("barkanwilarea").getContext('2d');
      var data = {
      labels : [
              <?php 
                $value = "";
                if($setFilterType == "kanwil"){
                  for($i=0; $i < count($line_graphs); $i++){
                    if($i == 0){
                      $value = "'".$line_graphs[$i]->kanwil."','";
                    }elseif($i == count($line_graphs)-1){
                      $value .= $line_graphs[$i]->kanwil."'";
                    }else{
                      $value .= $line_graphs[$i]->kanwil."','";
                    }
                  }
                }else{
                  for($i=0; $i < count($line_graphs); $i++){
                    if($i == 0){
                      $value = "'".$line_graphs[$i]->area."','";
                    }elseif($i == count($line_graphs)-1){
                      $value .= $line_graphs[$i]->area."'";
                    }else{
                      $value .= $line_graphs[$i]->area."','";
                    }
                  }
                }
                
                echo $value;
              ?>
              ],
              datasets: [
              {
              label: '<?php if($setFilterType == "kanwil") { echo'kanwil'; }else{echo 'area';} ?>',
              data: [ <?php for ($i = 0; $i < count($line_graphs); $i++) { ?>
                <?php echo $line_graphs[$i]->merchant_connected;?>,
                <?php } ?>
              ],
                backgroundColor: [
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)'
                ],
                borderColor: [
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)'
                ],
                borderWidth: 1
              }]
              };


            var options = {
            responsive: true,
            maintainAspectRatio: true,
            title : {
              display : true,
              position : "top",
              fontSize : 10,
              fontColor : "#111"
            },
            legend : {
              display : true,
              position : "bottom"
            },
            scales : {  
              yAxes : [{
                ticks: {
                  min: 0
                },
                scaleLabel: {
                  display: true
                }
              }]
            }
            };

            var chart = new Chart( ctx, {
            type : "bar",
            data : data,
            options : options
            });
    </script>



</html>
