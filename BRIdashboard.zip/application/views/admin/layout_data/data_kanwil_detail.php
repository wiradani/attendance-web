<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>
<body id="page-top">

<?php $this->load->view("admin/_partials/navbar.php") ?>


<div id="wrapper">

	<?php $this->load->view("admin/_partials/sidebar.php") ?>

	<div id="content-wrapper">

		<div class="container-fluid">

    <div class="card mb-3">
      <div class="card-header ">
      <div class="row">
        <div class="col-8">

              
              <h5 class="card-title p-3" >
                <label  style="font-size:80% !important;" id="timerJavaScript" name="timerJavaScript" class="control-label" for="basicinput">Tolerance</label>
                <?php 
                $form_field1 = '';
                echo $form_field1 .= "<select name='comboboxTimer' id='comboboxTimer' style='font-size:80% !important;'>
                    <option value='1440'".($valueTimer == '1440' ? ' selected' : '' )." >Last 1 Day</option>
                    <option value='2880'".($valueTimer == '2880' ? ' selected' : '' )." >Last 2 Days</option>
                    <option value='4320'".($valueTimer == '4320' ? ' selected' : '' )." >Last 3 Days</option>
                    <option value='7200'".($valueTimer == '7200' ? ' selected' : '' ).">Last 5 Days</option>
                    <option value='10080'".($valueTimer == '10080' ? ' selected' : '' ).">Last 7 Days</option>
                    <option value='20160'".($valueTimer == '20160' ? ' selected' : '' ).">Last 14 Days</option>
                    <option value='43200'".($valueTimer == '43200' ? ' selected' : '' ).">Last 30 Days</option>
                    <option value='86400'".($valueTimer == '86400' ? ' selected' : '' ).">Last 60 Days</option>
                    <option value='1290600'".($valueTimer == '1290600' ? ' selected' : '' ).">Last 90 Days</option>
                    </select>";
                  ?>
                </h5>
                </div>
        <div class="col-4">
              <div class="row">
                  <div class="col">
                  </div>
                  <div class="col-md-auto">
                    
                    <table class="none" border="1px" style="height: 50px;text-align: center; font-size: 50%; padding: 0px !important;float: right; margin: 0px;" >
                        <tr>
                          <th rowspan="2" style="font-weight: bold; font-size: 170%;">&nbspMerchant&nbsp</th>
                          <th style="color:#080DCC; font-size: 90%;">&nbspConnected&nbsp</th>
                          <th style="color:#000000; font-size: 90%;">&nbspRegistered&nbsp</th>
                        </tr>
                        <tr>
                          <td><span style="color:#080DCC; font-weight: bold; font-size: 160%;">&nbsp<?php echo $merchant_active;?>&nbsp</span></td>
                          <td><span style="color:#000000; font-weight: bold; font-size: 160%;">&nbsp<?php echo $merchant_total;?>&nbsp</span></td>
                        </tr>
                      </table>
                        
              <table class="none" border="1px" style="height: 50px;text-align: center; font-size: 50%; padding: 0px !important; float: right; margin: 0px;" >
                        <tr>
                          <th rowspan="2" style="font-weight: bold; font-size: 170%;">&nbspEDC&nbsp</th>
                          <th style="color:#080DCC; font-size: 90%;">&nbspConnected&nbsp</th>
                          <th style="color:#000000; font-size: 90%;">&nbspRegistered&nbsp</th>
                        </tr>
                        <tr>
                          <td><span style="color:#080DCC; font-weight: bold; font-size: 160%;">&nbsp<?php echo $terminal_active;?>&nbsp</span></td>
                          <td><span style="color:#000000; font-weight: bold; font-size: 160%;">&nbsp<?php echo $terminal_total;?>&nbsp</span></td>
                        </tr>
                </table>

                  </div>
              </div>
        </div>
    </div>
    </div>
        <div class="card-body" style="padding:6px;" >
                

        <div class="tab-content p-0">
                  <table id="dataTable" class="table table-bordered table-hover" style="font-size:80%">
                <thead>
                  <tr>
                    <th rowspan="2" style="text-align: center; width: 10%; vertical-align: middle; text-align: middle;">Kantor Wilayah</th>
                    <th rowspan="2" style="text-align: center; width: 10%;">Area</th>
                    <th colspan="4" style="text-align: center; color: #007EFF; font-weight: bold;">Merchant</th>
                    <th colspan="4" style="text-align: center; color: #B90BFD; font-weight: bold;">TERMINAL</th>
                    <th rowspan="2" style="text-align: center; width: 10%;">ACTION</th>
                  </tr>
                  <tr>
                    <th style="text-align: center; width: 10%; color: #007EFF; font-weight: bold;">CON</th>
                    <th style="text-align: center; width: 10%; color: #B90BFD; font-weight: bold;">DIS</th>
                    <th style="text-align: center; width: 10%; color: #001E48; font-weight: bold;">TOTAL</th>
                    <th style="text-align: center; width: 10%;">% CON</th>
                    <th style="text-align: center; width: 10%; color: #007EFF; font-weight: bold;">CON</th>
                    <th style="text-align: center; width: 10%; color: #B90BFD; font-weight: bold;">DIS</th>
                    <th style="text-align: center; width: 10%; color: #001E48; font-weight: bold;">TOTAL</th>
                    <th style="text-align: center; width: 10%;">% CON</th>
                  </tr>
                </thead>
                <tbody>                  
                  <?php $no=1; for ($i=0; $i < count($data_kanwil); $i++) { ?>
                  <tr>
                    <td style="text-align: center;"><?php echo $data_kanwil[$i]->kanwil;?></td>
                    <td style="text-align: center;"><?php echo $data_kanwil[$i]->area;?></td>
                    <td style="text-align: center;">
                      <a <?php if($data_kanwil[$i]->connected != "0"){ ?> href="<?php echo site_url("admin/data/area_status/connected_")?><?php echo $data_kanwil[$i]->area;?>" target="_blank" <?php } ?> id="tooltrip_connect" title="Connected" style="color: #007EFF; font-weight: bold;"><?php echo $data_kanwil[$i]->connected?></a>
                    </td>
                    <td style="text-align: center;">
                      <a <?php if($data_kanwil[$i]->disconnect != "0"){ ?> href="<?php echo site_url("admin/data/area_status/disconnected_")?><?php echo $data_kanwil[$i]->area;?>" target="_blank" <?php } ?> id="tooltrip_disconnect" title="Disconnected" style="color: #B90BFD; font-weight: bold;"><?php echo $data_kanwil[$i]->disconnect?></a>
                    </td>
                    <td style="text-align: center;">
                      <a <?php if($data_kanwil[$i]->total != "0"){ ?> href="<?php echo site_url("admin/data/area_status/total_")?><?php echo $data_kanwil[$i]->area;?>" target="_blank" <?php } ?> id="tooltrip_total" title="Total" style="color: #001E48; font-weight: bold;"><?php echo $data_kanwil[$i]->total?></a>
                    </td>
                    <td style="text-align: center;">
                      <?php echo round(($data_kanwil[$i]->connected/$data_kanwil[$i]->total)*100,2)."%"?>
                    </td>

                    <td style="text-align: center;">
                      <?php if (isset($data_kanwil[$i]->edc_connected)) { 
                              echo $data_kanwil[$i]->edc_connected; 
                            } 
                            else echo "0"; ?>
                    </td>
                    <td style="text-align: center;">
                      <?php if(isset($data_kanwil[$i]->edc_disconnect)){

                            echo $data_kanwil[$i]->edc_disconnect;
                          }
                          else echo "0";
                      ?>
                    </td>
                    <td style="text-align: center;">
                      <?php if(isset($data_kanwil[$i]->edc_total)){

                        echo $data_kanwil[$i]->edc_total;
                      }
                      else echo "0";
                      ?>
                    </td>
                    <td style="text-align: center;">
                      <?php if(isset($data_kanwil[$i]->edc_connected) && isset($data_kanwil[$i]->edc_total) ) {
                      
                          echo round(($data_kanwil[$i]->edc_connected/$data_kanwil[$i]->edc_total)*100,2)."%";
                        }
                        else echo "0 %";  
                          ?>
                    </td>
                    <td style="text-align: center;">
                      <button id="btnDetail" onclick="window.location.href='<?php echo site_url('admin/data/area_detail/').$data_kanwil[$i]->kanwil."_".$data_kanwil[$i]->area;?>'" type="button" class="btn btn-primary btn-xs" style="width:50px; height:20px; font-size:x-small; align-items: center; padding: 0px;">Detail</button>
                    </td>                    
                  </tr>
                  <?php $no++; } ?>
                </tbody>
              </table>
            </div>




        </div>
    </div>



    </div>
		<!-- /.container-fluid -->

		<!-- Sticky Footer -->
		<?php $this->load->view("admin/_partials/footer.php") ?>

	</div>
	<!-- /.content-wrapper -->

</div>
<!-- /#wrapper -->


<?php $this->load->view("admin/_partials/scrolltop.php") ?>
<?php $this->load->view("admin/_partials/modal.php") ?>
<?php $this->load->view("admin/_partials/js.php") ?>
    
</body>

<script type="text/javascript">
$(function () {
  $('#comboboxTimer').on('change', function() {
      var val = $(this).val();
      $.ajax({
          type: 'POST',
          url: '<?php echo site_url("admin/Overview/UpdateTimer")?>',
          data: 'timerPost=' + val,
          success: function(data) {
            <?php $valueSegment = $this->uri->segment('4');?>
            console.log(data);
            window.location.assign("<?php echo site_url("admin/data/kanwil_status/").$valueSegment; ?>");
          }
     }) 
  });
});        
</script>



</html>
