<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>
<body id="page-top">

<?php $this->load->view("admin/_partials/navbar.php") ?>


<div id="wrapper">

	<?php $this->load->view("admin/_partials/sidebar.php") ?>

	<div id="content-wrapper">

		<div class="container-fluid">

    <div class="card mb-3">
      <div class="card-header ">
      <div class="row">
        <div class="col-8">
          <form action="<?php echo base_url(); ?>index.php/admin/Data/queryParameter" method='post' class="form-inline">

                <div class="input-group mb-2 mr-sm-2">
                <label for="tolerance">Tolerance</label>
                &nbsp
                <select id="tolerance" name="tolerance" clas="custom-select mr-sm-2">
                  <option value="1440">Last 1 Days</option>
                  <option value="2880">Last 2 Days</option>
                  <option value="4320">Last 3 Days</option>
                  <option value="7200">Last 5 Days</option>
                  <option value="10080">Last 7 Days</option>
                  <option value="20160">Last 14 Days</option>
                  <option value="43200">Last 30 Days</option>
                  <option value="86400">Last 60 Days</option>
                  <option value="1290600">Last 90 Days</option>
                </select>
                </div>

                <div class="input-group mb-2 mr-sm-2">
                <label for="btn">Data</label>
                &nbsp
                <select id="btn" name="btn">
                  <option value="area">Area</option>
                  <option value="kanwil">Kanwil</option>
                  <option value="kcp">KCP</option>
                </select>
                </div>

                <div class="input-group mb-2 mr-sm-2">
                  <input class="btn btn-primary btn-sm " type="submit" value="Submit">
                </div>
           </form>
        </div>
        <div class="col-4">
              <div class="row">
                  <div class="col">
                  </div>
                  <div class="col-md-auto">
                    
                    <table class="none" border="1px" style="height: 50px;text-align: center; font-size: 50%; padding: 0px !important;float: right; margin: 0px;" >
                        <tr>
                          <th rowspan="2" style="font-weight: bold; font-size: 170%;">&nbspMerchant&nbsp</th>
                          <th style="color:#080DCC; font-size: 90%;">&nbspConnected&nbsp</th>
                          <th style="color:#000000; font-size: 90%;">&nbspRegistered&nbsp</th>
                        </tr>
                        <tr>
                          <td><span style="color:#080DCC; font-weight: bold; font-size: 160%;">&nbsp<?php echo $merchant_active;?>&nbsp</span></td>
                          <td><span style="color:#000000; font-weight: bold; font-size: 160%;">&nbsp<?php echo $merchant_total;?>&nbsp</span></td>
                        </tr>
                      </table>
                        
              <table class="none" border="1px" style="height: 50px;text-align: center; font-size: 50%; padding: 0px !important; float: right; margin: 0px;" >
                        <tr>
                          <th rowspan="2" style="font-weight: bold; font-size: 170%;">&nbspEDC&nbsp</th>
                          <th style="color:#080DCC; font-size: 90%;">&nbspConnected&nbsp</th>
                          <th style="color:#000000; font-size: 90%;">&nbspRegistered&nbsp</th>
                        </tr>
                        <tr>
                          <td><span style="color:#080DCC; font-weight: bold; font-size: 160%;">&nbsp<?php echo $terminal_active;?>&nbsp</span></td>
                          <td><span style="color:#000000; font-weight: bold; font-size: 160%;">&nbsp<?php echo $terminal_total;?>&nbsp</span></td>
                        </tr>
                </table>

                  </div>
              </div>
        </div>
    </div>
    </div>
        <div class="card-body" style="padding:6px;" >
                

            


        <div class="tab-content p-0">
                  <table id="dataTable" class="table table-bordered table-hover" style="font-size:85%">
                <thead>
                  <tr>
                    <th style="text-align: center;">Merchant Name</th>
                    <th style="text-align: center;">Kantor Wilayah</th>
                    <th style="text-align: center;">Area</th>
                    
                    <th style="text-align: center;">Merchnat Type</th>
                    <th style="text-align: center; color: #007EFF; font-weight: bold;">CONNECTED</th>
                    <th style="text-align: center; color: #B90BFD; font-weight: bold;">DISCONNECTED</th>
                    <th style="text-align: center; color: #001E48; font-weight: bold;">TOTAL (TERMINAL)</th>
                    <th style="text-align: center; width: 130px;">% CONNECTED</th>
                    <!-- <th style="text-align: center;">MOS</th> -->
                    <th style="text-align: center;">ACTION</th>
                  </tr>
                </thead>
                <tbody>                  
                  <?php $no=1; for ($i=0; $i < count($data_area2); $i++) { ?>
                  <tr>
                    <td style="text-align: center;"><?php echo $data_area2[$i]->merchant_code;?></td>
                    <td style="text-align: center;"><?php echo $data_area2[$i]->kanwil;?></td>
                    <td style="text-align: center;"><?php echo $data_area2[$i]->area;?></td>
                    
                    <td style="text-align: center;"><?php 
                      if (substr($data_area2[$i]->merchant_code, 1, 1)==1){
                        echo "COCO [1]";
                      } else if (substr($data_area2[$i]->merchant_code, 1, 1)==4){
                        echo "DODO [4]";
                      } else if (substr($data_area2[$i]->merchant_code, 1, 1)==3){
                        echo "DODO [3]";
                      } else if (substr($data_area2[$i]->merchant_code, 1, 1)==2){
                        echo "DODO [2]";
                      } else {
                        echo "undefined [".substr($data_area2[$i]->merchant_code, 1, 1)."]";
                      }?>
                    </td>
                    <td style="text-align: center;">
                      <a <?php if($data_area2[$i]->connected != "0"){ ?> href="<?php echo site_url("admin/data/area_terminal/connected_")?><?php echo $data_area2[$i]->merchant_code;?>" target="_blank" <?php } ?> id="tooltrip_connect" title="Connected" style="color: #007EFF; font-weight: bold;"><?php echo $data_area2[$i]->connected?></a>
                    </td>
                    <td style="text-align: center;">
                      <a <?php if($data_area2[$i]->disconnect != "0"){ ?> href="<?php echo site_url("admin/data/area_terminal/disconnected_")?><?php echo $data_area2[$i]->merchant_code;?>" target="_blank" <?php } ?> id="tooltrip_disconnect" title="Disconnected" style="color: #B90BFD; font-weight: bold;"><?php echo $data_area2[$i]->disconnect?></a>
                    </td>
                    <td style="text-align: center;">  
                      <a <?php if($data_area2[$i]->total != "0"){ ?> href="<?php echo site_url("admin/data/area_terminal/total_")?><?php echo $data_area2[$i]->merchant_code;?>" target="_blank" <?php } ?> id="tooltrip_total" title="Total" style="color: #001E48; font-weight: bold;"><?php echo $data_area2[$i]->total?></a>
                    </td>
                    <td style="text-align: center;">
                      <?php echo round(($data_area2[$i]->connected/$data_area2[$i]->total)*100,2)."%"?>
                    </td>
                    <!-- <td style="text-align: center;">
                      <?php if ($data_area2[$i]->mos === 'OK') { ?>
                        <img src="<?php echo base_url("assets/image/checklist.png")?>" style="height: 15px; width: 15px;">   
                      <?php }else{ ?>     
                        <img src="<?php echo base_url("assets/image/silang.png")?>" style="height: 13px; width: 13px;">   
                      <?php } ?>              
                    </td> -->
                    <td style="text-align: center;">
                      <?php if($identity == "mor"){
                        $myLogGeneral = "Perfomance MOR ".(substr($data_area2[$i]->merchant_code, 0,1));
                      }else{
                        $myLogGeneral = "Perfomance ".$data_area2[$i]->kanwil." ".$data_area2[$i]->area;
                      }?>
                      <button id="btnDetail" onclick="window.location.href='<?php echo site_url('admin/data/terminal/').$data_area2[$i]->merchant_code ?>'" type="button" class="btn btn-primary btn-xs" style="width:50px; height:20px; font-size:x-small; align-items: center; padding: 0px;">Detail</button>
                    </td>                    
                  </tr>
                  <?php $no++; } ?>
                </tbody>
              </table>
            </div>




        </div>
    </div>



    </div>
		<!-- /.container-fluid -->

		<!-- Sticky Footer -->
		<?php $this->load->view("admin/_partials/footer.php") ?>

	</div>
	<!-- /.content-wrapper -->

</div>
<!-- /#wrapper -->


<?php $this->load->view("admin/_partials/scrolltop.php") ?>
<?php $this->load->view("admin/_partials/modal.php") ?>
<?php $this->load->view("admin/_partials/js.php") ?>
    
</body>

<script type="text/javascript">
$(function () {
  $('#comboboxTimer').on('change', function() {
      var val = $(this).val();
      $.ajax({
          type: 'POST',
          url: '<?php echo site_url("admin/Overview/UpdateTimer")?>',
          data: 'timerPost=' + val,
          success: function(data) {
            <?php $valueSegment = $this->uri->segment('4');?>
            console.log(data);
            window.location.assign("<?php echo site_url("admin/data/area_detail/").$valueSegment; ?>");
          }
     }) 
  });
});        
</script>



</html>
