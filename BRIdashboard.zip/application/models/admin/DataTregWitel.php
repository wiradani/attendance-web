<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DataTregWitel extends CI_Model { 

    //--------------GET DATA MOR TABLE 2 MOR STATUS COCO DODO --------------//
    public function getareadmerchant($kanwil,$valueTimer){
        $query = $this->db->query("SELECT a.kanwil, a.area, total, IF(b.connected IS NULL,0,b.connected) as connected, IF(c.disconnect IS NULL, 0, c.disconnect) as disconnect, IF(e.edc_connected IS NULL,0,e.edc_connected) as edc_connected, IF(f.edc_disconnect IS NULL, 0, f.edc_disconnect) as edc_disconnect, IF(g.edc_total IS NULL, 0, g.edc_total) as edc_total
				FROM (SELECT count(*) as total, area, merchant_code,  kanwil  FROM (
				    SELECT area, kanwil, merchant_code,  max(created_date) created_date FROM `heartbeat_terminal` 
				        WHERE kanwil = '".$kanwil."'
				        GROUP BY merchant_code, merchant_name
					) AS A GROUP BY kanwil
				)as a
				LEFT JOIN (
				    SELECT count(*) as connected, area, kanwil FROM (
				        SELECT area, kanwil, merchant_code,  max(created_date) created_date 
				        FROM `heartbeat_terminal` WHERE kanwil = '".$kanwil."' GROUP BY merchant_code, merchant_name
				    ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL '".$valueTimer."' MINUTE) GROUP BY kanwil
				)as b ON b.kanwil = a.kanwil
				LEFT JOIN (
				    SELECT count(*) as disconnect, area, kanwil FROM (
				        SELECT area, kanwil, merchant_code,  max(created_date) created_date 
				        FROM `heartbeat_terminal` WHERE kanwil = '".$kanwil."' GROUP BY merchant_code, merchant_name  
				    ) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL '".$valueTimer."' MINUTE) GROUP BY kanwil
				)as c ON c.kanwil = a.kanwil
				LEFT JOIN (
				    SELECT count(*) as edc_connected, area, kanwil FROM (
				        SELECT area, kanwil, merchant_code,  max(created_date) created_date 
				        FROM `heartbeat_terminal` WHERE kanwil = '".$kanwil."' GROUP BY sn
				    ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL '".$valueTimer."' MINUTE) GROUP BY kanwil
				)as e ON e.kanwil = a.kanwil
				LEFT JOIN (
				    SELECT count(*) as edc_disconnect, area, kanwil FROM (
				        SELECT area, kanwil, merchant_code,  max(created_date) created_date 
				        FROM `heartbeat_terminal` WHERE kanwil = '".$kanwil."' GROUP BY sn
				    ) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL '".$valueTimer."' MINUTE) GROUP BY kanwil
				)as f ON f.kanwil = a.kanwil
                LEFT JOIN (
                    SELECT count(*) as edc_total, area, merchant_code, kanwil  FROM (
				    	SELECT area, kanwil, merchant_code,  max(created_date) created_date FROM `heartbeat_terminal` 
				        WHERE kanwil = '".$kanwil."'
				        GROUP BY sn
					) AS G GROUP BY kanwil
				)as g ON g.kanwil = a.kanwil");
		$data['kanwil'] = $query->result();	
        
        return $data;
    }


    //--------------GET DATA MOR TABLE 1 TREG--------------//
	public function getTregWitel($valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connect IS NULL,0,b.connect) as connect, IF(c.disconnect is null,0,c.disconnect) as disconnect, IF(e.edc_total is null,0,e.edc_total) as edc_total, IF(f.edc_connect is null,0,f.edc_connect) as edc_connect, IF(g.edc_disconnect is null,0,g.edc_disconnect) as edc_disconnect FROM (
			SELECT count(*) as total, kanwil as mor FROM (SELECT kanwil, merchant_code, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY merchant_code, kanwil) AS A group by kanwil) as a 
            LEFT JOIN (SELECT count(*) as connect, kanwil as mor FROM (SELECT kanwil, merchant_code, max(created_date) created_date FROM `heartbeat_terminal` 	GROUP BY merchant_code, kanwil ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) group by kanwil ) as b ON b.mor = a.mor 
            LEFT JOIN ( SELECT count(*) as disconnect, kanwil as mor FROM (SELECT kanwil, merchant_code, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY merchant_code, kanwil ) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) group by kanwil) as c ON c.mor = a.mor
            LEFT JOIN (SELECT count(*) as edc_total, kanwil as mor FROM (SELECT kanwil, merchant_code, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY sn, kanwil) AS A group by kanwil) as e ON e.mor = a.mor
            LEFT JOIN (SELECT count(*) as edc_connect, kanwil as mor FROM (SELECT kanwil, merchant_code, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY sn, kanwil ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) group by kanwil ) as f ON f.mor = a.mor 
            LEFT JOIN ( SELECT count(*) as edc_disconnect, kanwil as mor FROM (SELECT kanwil, merchant_code, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY sn, kanwil ) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) group by kanwil) as g ON g.mor = a.mor");
		$data['TregWitel'] = $query->result();		
		return $data;
    }

    //--------------CDT KANWIL 1 CONNECTED--------------//
	public function getKanwilConnected($kanwil, $valueTimer){
		$query = $this->db->query("SELECT a.kanwil, a.area, total, IF(b.connected IS NULL,0,b.connected) as connected, IF(c.disconnect IS NULL, 0, c.disconnect) as disconnect
				FROM (SELECT * FROM (SELECT count(*) as total, kanwil, area, merchant_code, merchant_name, max(created_date) created_date FROM (
				SELECT area, kanwil, merchant_code, merchant_name, max(created_date) created_date FROM `heartbeat_terminal` WHERE kanwil = '".$kanwil."' GROUP BY merchant_code, merchant_name) AS A GROUP BY area) AS DSDF WHERE created_date > DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE)
				)as a
				LEFT JOIN (
				    SELECT count(*) as connected, area FROM (
				        SELECT area, kanwil, merchant_code, merchant_name, max(created_date) created_date 
				        FROM `heartbeat_terminal` WHERE kanwil = '".$area."' GROUP BY merchant_code, merchant_name  
				    ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) GROUP BY kanwil
				)as b ON b.kanwil = a.kanwil
				LEFT JOIN (
				    SELECT count(*) as disconnect, area FROM (
				        SELECT area, kanwil, merchant_code, merchant_name, max(created_date) created_date 
				        FROM `heartbeat_terminal` WHERE kanwil = '".$area."' GROUP BY merchant_code, merchant_name  
				    ) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) GROUP BY kanwil
				)as c ON c.kanwil = a.kanwil");
		return $query->result();
	}

	//--------------CDT KANWIL 1 DISCONNECTED--------------//
	public function getKanwillDisConnected($kanwil, $valueTimer){
		$query = $this->db->query("SELECT a.kanwil, a.area, total, IF(b.connected IS NULL,0,b.connected) as connected, IF(c.disconnect IS NULL, 0, c.disconnect) as disconnect
				FROM (SELECT count(merchant_code) total, kanwil, area, created_date FROM (
				SELECT area, kanwil, merchant_code, merchant_name, max(created_date) created_date 
				    FROM `heartbeat_terminal` 
				    WHERE kanwil = '".$kanwil."' 
				       GROUP BY merchant_code, merchant_name
				    )as a
				    group by area, kanwil  
					ORDER BY `total`  DESC
				)as a
				LEFT JOIN (
				    SELECT count(*) as connected, area,kanwil FROM (
				        SELECT area, kanwil, merchant_code, merchant_name, max(created_date) created_date 
				        FROM `heartbeat_terminal` WHERE kanwil = '".$kanwil."' GROUP BY merchant_code, merchant_name
				    ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) GROUP BY kanwil
				)as b ON b.kanwil = a.kanwil
				LEFT JOIN (
				    SELECT count(*) as disconnect, area,kanwil FROM (
				        SELECT area, kanwil, merchant_code, merchant_name, max(created_date) created_date 
				        FROM `heartbeat_terminal` WHERE kanwil = '".$kanwil."' GROUP BY merchant_code, merchant_name  
				    ) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) GROUP BY kanwil
				)as c ON c.kanwil = a.kanwil");
		return $query->result();
	}

	//--------------CDT KANWIL 1 TOTAL--------------//
	public function getKanwilTotal($kanwil, $valueTimer){
		$query = $this->db->query("SELECT a.kanwil, a.area, total, IF(b.connected IS NULL,0,b.connected) as connected, IF(c.disconnect IS NULL, 0, c.disconnect) as disconnect
				FROM (SELECT count(*) as total, area, merchant_code, merchant_name, kanwil as kanwil FROM (
				    SELECT area, kanwil, merchant_code, merchant_name, max(created_date) created_date FROM `heartbeat_terminal` 
				        WHERE kanwil = '".$kanwil."'
				        GROUP BY merchant_code, merchant_name
					) AS A GROUP BY kanwil
				)as a
				LEFT JOIN (
				    SELECT count(*) as connected, area,kanwil FROM (
				        SELECT area, kanwil, merchant_code, merchant_name, max(created_date) created_date 
				        FROM `heartbeat_terminal` WHERE kanwil = '".$kanwil."' GROUP BY merchant_code, merchant_name  
				    ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) GROUP BY kanwil
				)as b ON b.kanwil = a.kanwil
				LEFT JOIN (
				    SELECT count(*) as disconnect, kanwil,area FROM (
				        SELECT kanwil, area, merchant_code, merchant_name, max(created_date) created_date 
				        FROM `heartbeat_terminal` WHERE kanwil = '".$kanwil."' GROUP BY merchant_code, merchant_name  
				    ) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) GROUP BY kanwil
				)as c ON c.kanwil = a.kanwil");
		return $query->result();
	}
    
    



}