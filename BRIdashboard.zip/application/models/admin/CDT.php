<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CDT extends CI_Model {

    public function getAreaConnected($paramArea,$valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connected is null,0,b.connected) as connected, 
			if(c.disconnect is null,0,c.disconnect) as disconnect FROM (
				SELECT kanwil, total, merchant_code, area  FROM (
				SELECT * FROM (SELECT COUNT(*) as total, sn, kanwil, area, merchant_code, merchant_name, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY merchant_code, merchant_name) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) and area = '".$paramArea."' group by merchant_code,merchant_name,sn) AS A group by merchant_code  
					ORDER BY `A`.`total`  DESC
			)as a
			LEFT JOIN (
			    SELECT COUNT(*) as connected, merchant_code, area FROM (
			        SELECT kanwil, merchant_code,merchant_name,sn, area, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '".$paramArea."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as b ON b.merchant_code = a.merchant_code
			LEFT JOIN (
			    SELECT COUNT(*) as disconnect, merchant_code, area FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '".$paramArea."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as c ON c.merchant_code = a.merchant_code 
			ORDER BY b.connected desc");
		$value = $query->result();
		$data['mor']		= $value;		
		return $data;
    }
    

    public function getAreaDisconnected($paramArea,$valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connected is null,0,b.connected) as connected, 
			if(c.disconnect is null,0,c.disconnect) as disconnect FROM (
				SELECT kanwil, total, merchant_code, area  FROM (
				SELECT * FROM (SELECT COUNT(*) as total, sn, kanwil, area, merchant_code, merchant_name, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY merchant_code, merchant_name) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) and area = '".$paramArea."' group by merchant_code,merchant_name,sn) AS A group by merchant_code  
					ORDER BY `A`.`total`  DESC
			)as a
			LEFT JOIN (
			    SELECT COUNT(*) as connected, merchant_code, area  FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '".$paramArea."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as b ON b.merchant_code = a.merchant_code
			LEFT JOIN (
			    SELECT COUNT(*) as disconnect, merchant_code, area  FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '".$paramArea."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as c ON c.merchant_code = a.merchant_code
            ORDER BY b.connected desc ");
		$value = $query->result();
		$data['mor']		= $value;		
		return $data;
	}


    public function getAreaTotal($paramArea,$valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connected is null,0,b.connected) as connected, 
			if(c.disconnect is null,0,c.disconnect) as disconnect FROM (
			    SELECT COUNT(*) as total, kanwil, merchant_code, area FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where substr(merchant_code,1,1) = '".$paramArea."'
			        group by merchant_code,merchant_name,sn
			    ) AS A group by merchant_code
			)as a
			LEFT JOIN (
			    SELECT COUNT(*) as connected, kanwil, merchant_code, area FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where substr(merchant_code,1,1) = '".$paramArea."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as b ON b.merchant_code = a.merchant_code
			LEFT JOIN (
			    SELECT COUNT(*) as disconnect, kanwil, merchant_code, area FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where substr(merchant_code,1,1) = '".$paramArea."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as c ON c.merchant_code = a.merchant_code 
            ORDER BY b.connected desc");
		$value = $query->result();
		$data['mor']		= $value;		
		return $data;
    }
    

    //-------------- GET WITEL CONNECTED --------------//
	public function getMorWitelConnected($area,$valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connected is null,0,b.connected) as connected, 
			if(c.disconnect is null,0,c.disconnect) as disconnect FROM (
				SELECT kanwil, total, merchant_code, area FROM (
				SELECT * FROM (SELECT COUNT(*) as total, sn, kanwil, area, merchant_code, merchant_name, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY merchant_code, merchant_name) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) and area = '".$area."' group by merchant_code,merchant_name,sn) AS A group by merchant_code  
					ORDER BY `A`.`total`  DESC
			)as a
			LEFT JOIN (
			    SELECT COUNT(*) as connected, kanwil, merchant_code, area FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '".$area."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as b ON b.merchant_code = a.merchant_code
			LEFT JOIN (
			    SELECT COUNT(*) as disconnect, kanwil, merchant_code, area FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '".$area."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as c ON c.merchant_code = a.merchant_code 
			ORDER BY b.connected desc");
		$value = $query->result();
		$data['mor']		= $value;		
		return $data;
	}

	//-------------- GET WITEL DISCONNECTED --------------//
	public function getMorWitelDisconnected($area,$valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connected is null,0,b.connected) as connected, 
			if(c.disconnect is null,0,c.disconnect) as disconnect FROM (
				SELECT kanwil, total, merchant_code, area FROM (
				SELECT * FROM (SELECT COUNT(*) as total, sn, kanwil, area, merchant_code, merchant_name, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY merchant_code, merchant_name) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) and area = '".$area."' group by merchant_code,merchant_name,sn) AS A group by merchant_code  
					ORDER BY `A`.`total`  DESC
			)as a
			LEFT JOIN (
			    SELECT COUNT(*) as connected, kanwil, merchant_code, area FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '".$area."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as b ON b.merchant_code = a.merchant_code
			LEFT JOIN (
			    SELECT COUNT(*) as disconnect, kanwil, merchant_code, area FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '".$area."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as c ON c.merchant_code = a.merchant_code 
			ORDER BY b.connected desc");
		$value = $query->result();
		$data['mor']		= $value;		
		return $data;
	}

	//-------------- GET WITEL TOTAL --------------//
	public function getMorWitelTotal($area,$valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connected is null,0,b.connected) as connected, 
			if(c.disconnect is null,0,c.disconnect) as disconnect FROM (
				SELECT kanwil, total, merchant_code, area FROM (
				SELECT * FROM (SELECT COUNT(*) as total, sn, kanwil, area, merchant_code, merchant_name, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY merchant_code, merchant_name) AS A WHERE area = '".$area."' group by merchant_code,merchant_name,sn) AS A group by merchant_code  
					ORDER BY `A`.`total`  DESC
			)as a
			LEFT JOIN (
			    SELECT COUNT(*) as connected, kanwil, merchant_code, area FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '".$area."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as b ON b.merchant_code = a.merchant_code
			LEFT JOIN (
			    SELECT COUNT(*) as disconnect, kanwil, area, merchant_code FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '".$area."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as c ON c.merchant_code = a.merchant_code 
			ORDER BY b.connected desc");
		$value = $query->result();
		$data['mor']		= $value;		
		return $data;
	}

	//--------------GET TERMINAL CONNECTED--------------//
	public function getAreaTerminalConnected($valueTimer,$valueMorGet){
		$query = $this->db->query("
      	SELECT kanwil, area,  merchant_name, sn,device_type1 as device_type, created_date, IF(`created_date` < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE), 'Disconnected', 'Connected') as status FROM (
      	SELECT * FROM (
	      	SELECT * FROM (
		      	SELECT DISTINCT kanwil, area, merchant_code, merchant_name, sn1 FROM (
			      	SELECT kanwil, area, merchant_code, merchant_name, sn as sn1, max(created_date) created_date, device_type FROM `heartbeat_terminal` 
				    	where merchant_code = '".$valueMorGet."' group by merchant_code, merchant_name, sn1, device_type ORDER by created_date desc) AS A where `created_date` > DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) ORDER BY `A`.`sn1` ASC) as ga INNER JOIN (
				  	SELECT sn, device_type, max(created_date) created_date FROM heartbeat_terminal WHERE merchant_code = '".$valueMorGet."' GROUP by sn ORDER by created_date DESC) as ge on ge.sn = ga.sn1 ORDER BY `ge`.`created_date`  DESC) AS data1 INNER JOIN (
				    SELECT sn AS sn0, device_type as device_type1 from heartbeat_terminal WHERE merchant_code = '".$valueMorGet."' ORDER by device_type DESC) as data2 ON data2.sn0 = data1.sn GROUP by data2.sn0 desc) AS C where created_date > DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE)
		");
		$data = $query->result();	
		return $data;
	}

	//--------------GET TERMINAL DISCONNECTED--------------//
	public function getAreaTerminalDisconnected($valueTimer,$valueMorGet){
		$query = $this->db->query("
      SELECT kanwil, area,  merchant_name, sn, device_type1 as device_type, created_date, IF(`created_date` < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE), 'Disconnected', 'Connected') as status FROM (SELECT * FROM (SELECT * FROM (SELECT DISTINCT kanwil, area, merchant_code, merchant_name, sn1 FROM (SELECT kanwil, area, merchant_code, merchant_name, sn as sn1, max(created_date) created_date, device_type FROM `heartbeat_terminal` where merchant_code = '".$valueMorGet."' group by merchant_code, merchant_name, sn1, device_type ORDER by created_date desc) AS A where `created_date` < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) ORDER BY `A`.`sn1` ASC) as ga INNER JOIN (SELECT sn, device_type, max(created_date) created_date FROM heartbeat_terminal WHERE merchant_code = '".$valueMorGet."' GROUP by sn ORDER by created_date DESC) as ge on ge.sn = ga.sn1 ORDER BY `ge`.`created_date`  DESC) AS data1 INNER JOIN (SELECT sn AS sn0, device_type as device_type1 from heartbeat_terminal WHERE merchant_code = '".$valueMorGet."' ORDER by device_type DESC) as data2 ON data2.sn0 = data1.sn GROUP by data2.sn0 desc) AS C where created_date < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE)
		");
		$data = $query->result();	
		return $data;
	}

	//--------------GET TERMINAL DISCONNECTED--------------//
	public function getAreaTerminalTotal($valueTimer,$valueMorGet){
		$query = $this->db->query("
      SELECT kanwil, area, merchant_name, sn, device_type1 as device_type, created_date, IF(`created_date` < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE), 'Disconnected', 'Connected') as status FROM (SELECT * FROM (SELECT * FROM (SELECT DISTINCT kanwil, area, merchant_code, merchant_name, sn1 FROM (SELECT kanwil, area, merchant_code, merchant_name, sn as sn1, max(created_date) created_date, device_type FROM `heartbeat_terminal` where merchant_code = '".$valueMorGet."' group by merchant_code, merchant_name, sn1, device_type ORDER by created_date desc) AS A ORDER BY `A`.`sn1` ASC) as ga INNER JOIN (SELECT sn, device_type, max(created_date) created_date FROM heartbeat_terminal WHERE merchant_code = '".$valueMorGet."' GROUP by sn ORDER by created_date DESC) as ge on ge.sn = ga.sn1 ORDER BY `ge`.`created_date`  DESC) AS data1 INNER JOIN (SELECT sn AS sn0, device_type as device_type1 from heartbeat_terminal WHERE merchant_code = '".$valueMorGet."' ORDER by device_type DESC) as data2 ON data2.sn0 = data1.sn GROUP by data2.sn0 desc) AS C
		");
		$data = $query->result();	
		return $data;
	}

	//--------------GET KCP DATA--------------//

	public function getKcpConnected($paramKcp,$valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connected is null,0,b.connected) as connected, 
			if(c.disconnect is null,0,c.disconnect) as disconnect FROM (
				SELECT kanwil, total, merchant_code, area, kcp  FROM (
				SELECT * FROM (SELECT COUNT(*) as total, sn, kanwil, area, merchant_code, merchant_name, kcp, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY merchant_code, merchant_name) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) and kcp = '".$paramKcp."' group by merchant_code,merchant_name,sn) AS A group by merchant_code  
					ORDER BY `A`.`total`  DESC
			)as a
			LEFT JOIN (
			    SELECT COUNT(*) as connected, merchant_code, area FROM (
			        SELECT kanwil, merchant_code,merchant_name,sn, area, kcp, max(created_date) created_date
			        FROM `heartbeat_terminal` where kcp = '".$paramKcp."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as b ON b.merchant_code = a.merchant_code
			LEFT JOIN (
			    SELECT COUNT(*) as disconnect, merchant_code, area, kcp FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, kcp, max(created_date) created_date
			        FROM `heartbeat_terminal` where kcp = '".$paramKcp."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as c ON c.merchant_code = a.merchant_code 
			ORDER BY b.connected desc");
		$value = $query->result();
		$data['mor']		= $value;		
		return $data;
    }
    

    public function getKcpDisconnected($paramKcp,$valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connected is null,0,b.connected) as connected, 
			if(c.disconnect is null,0,c.disconnect) as disconnect FROM (
				SELECT kanwil, total, merchant_code, area, kcp  FROM (
				SELECT * FROM (SELECT COUNT(*) as total, sn, kanwil, area, merchant_code, merchant_name, kcp, max(created_date) created_date FROM `heartbeat_terminal` GROUP BY merchant_code, merchant_name) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) and kcp = '".$paramKcp."' group by merchant_code,merchant_name,sn) AS A group by merchant_code  
					ORDER BY `A`.`total`  DESC
			)as a
			LEFT JOIN (
			    SELECT COUNT(*) as connected, merchant_code, area, kcp  FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, kcp, max(created_date) created_date
			        FROM `heartbeat_terminal` where kcp = '".$paramKcp."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as b ON b.merchant_code = a.merchant_code
			LEFT JOIN (
			    SELECT COUNT(*) as disconnect, merchant_code, area, kcp  FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, kcp, max(created_date) created_date
			        FROM `heartbeat_terminal` where kcp = '".$paramKcp."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as c ON c.merchant_code = a.merchant_code
            ORDER BY b.connected desc ");
		$value = $query->result();
		$data['mor']		= $value;		
		return $data;
	}


    public function getKcpTotal($paramKcp,$valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connected is null,0,b.connected) as connected, 
			if(c.disconnect is null,0,c.disconnect) as disconnect FROM (
			    SELECT COUNT(*) as total, kanwil, merchant_code, area, kcp FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, kcp,max(created_date) created_date
			        FROM `heartbeat_terminal` where kcp = '".$paramKcp."'
			        group by merchant_code,merchant_name,sn
			    ) AS A group by merchant_code
			)as a
			LEFT JOIN (
			    SELECT COUNT(*) as connected, kanwil, merchant_code, area FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, kcp, max(created_date) created_date
			        FROM `heartbeat_terminal` where kcp = '".$paramKcp."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as b ON b.merchant_code = a.merchant_code
			LEFT JOIN (
			    SELECT COUNT(*) as disconnect, kanwil, merchant_code, area FROM (
			        SELECT kanwil, area, merchant_code,merchant_name,sn, kcp, max(created_date) created_date
			        FROM `heartbeat_terminal` where kcp = '".$paramKcp."'
			        group by merchant_code,merchant_name,sn
			    ) AS A 
			     where `created_date` < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as c ON c.merchant_code = a.merchant_code 
            ORDER BY b.connected desc");
		$value = $query->result();
		$data['mor']		= $value;		
		return $data;
    }




 }