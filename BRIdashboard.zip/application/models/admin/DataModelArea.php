<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DataModelArea extends CI_Model {

    public function getTableArea($valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connect IS NULL,0,b.connect) as connect, IF(c.disconnect is null,0,c.disconnect) as disconnect, IF(e.edc_connect IS NULL,0,e.edc_connect) as edc_connect, IF(f.edc_disconnect IS NULL,0,f.edc_disconnect) as edc_disconnect, g.edc_total FROM (
				SELECT count(*) as total, area as area FROM (SELECT merchant_code, max(created_date) created_date, area FROM `heartbeat_terminal` GROUP BY merchant_code) AS A group by area) as a 
				LEFT JOIN (SELECT count(*) as connect, area as mor FROM (SELECT merchant_code, max(created_date) created_date, area FROM `heartbeat_terminal` GROUP BY merchant_code ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) group by area ) as b ON b.mor = a.area 
				LEFT JOIN ( SELECT count(*) as disconnect, area as mor FROM (SELECT merchant_code, max(created_date) created_date,area FROM `heartbeat_terminal` GROUP BY merchant_code ) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) group by area) as c ON c.mor = a.area 
                LEFT JOIN (SELECT count(*) as edc_connect, area as mor FROM (SELECT sn, merchant_code, max(created_date) created_date, area FROM `heartbeat_terminal` GROUP BY sn ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) group by area ) as e ON e.mor = a.area
				LEFT JOIN ( SELECT count(*) as edc_disconnect, area as mor FROM (SELECT merchant_code, max(created_date) created_date, area FROM `heartbeat_terminal` GROUP BY sn ) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) group by area) as f ON f.mor = a.area
				LEFT JOIN (SELECT count(*) as edc_total, area as mor FROM (SELECT merchant_code, max(created_date) created_date, area FROM `heartbeat_terminal` GROUP BY sn) AS A group by area) as g ON g.mor = a.area");      
        $data['mor'] = $query->result();		
		return $data;
	}


	public function getTableArea2($paramArea,$valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connected is null,0,b.connected) as connected, 
			if(c.disconnect is null,0,c.disconnect) as disconnect FROM (
			    SELECT COUNT(*) as total, kanwil, area, merchant_code FROM (
			        SELECT kanwil, area, merchant_code,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '$paramArea' 
			        group by merchant_code,sn
			    ) AS A group by merchant_code
			)as a
			LEFT JOIN (
			    SELECT COUNT(*) as connected, kanwil, area, merchant_code FROM (
			        SELECT kanwil, area, merchant_code,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '$paramArea'
			        group by merchant_code,sn
			    ) AS A 
			     where `created_date` > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as b ON b.merchant_code = a.merchant_code
			LEFT JOIN (
			    SELECT COUNT(*) as disconnect, kanwil, area, merchant_code FROM (
			        SELECT kanwil, area, merchant_code,sn, max(created_date) created_date
			        FROM `heartbeat_terminal` where area = '$paramArea'
			        group by merchant_code,sn
			    ) AS A 
			     where `created_date` < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			    group by merchant_code
			) as c ON c.merchant_code = a.merchant_code 
			ORDER BY b.connected desc");
		$value = $query->result();

		$data['mor']		= $value;
		
		return $data;
	}

	//--------------GET TERMINAL --------------//
	public function getTerminal($param1,$valueTimer){
		$query = $this->db->query("
			SELECT kanwil, area, merchant_code, merchant_name, sn, device_type1 as device_type, created_date, IF(`created_date` < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE), 'Disconnected', 'Connected') as status FROM (
			SELECT * FROM (
			SELECT * FROM (
			SELECT DISTINCT kanwil, area, merchant_code, merchant_name, sn1 FROM (
			SELECT kanwil, area, merchant_code, merchant_name, sn as sn1, max(created_date) created_date, device_type FROM `heartbeat_terminal` where merchant_code = '$param1' group by merchant_code, merchant_name, sn1, device_type ORDER by created_date desc) AS A ORDER BY `A`.`sn1` ASC) as ga INNER JOIN (
			SELECT sn, device_type, max(created_date) created_date FROM heartbeat_terminal WHERE merchant_code = '$param1' GROUP by sn ORDER by created_date DESC) as ge on ge.sn = ga.sn1 ORDER BY `ge`.`created_date`  DESC) AS data1 INNER JOIN (
			SELECT sn AS sn0, device_type as device_type1 from heartbeat_terminal WHERE merchant_code = '$param1' ORDER by device_type DESC) as data2 ON data2.sn0 = data1.sn GROUP by data2.sn0 desc) AS C
		");
		$data['terminal'] = $query->result();	
		return $data;
	}


}