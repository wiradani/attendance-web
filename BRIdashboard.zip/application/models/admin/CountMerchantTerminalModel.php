<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CountMerchantTerminalModel extends CI_Model { 


    public function getByArea($valueTimer){
		$query = $this->db->query("
			SELECT count(*) as result FROM (SELECT max(created_date) created_date FROM `heartbeat_terminal` GROUP BY merchant_code) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			");
		$query2 = $this->db->query("
			SELECT COUNT(*) as result FROM (SELECT distinct(merchant_code) FROM `heartbeat_terminal`) as A
		");
		$query3 = $this->db->query("
			SELECT COUNT(*) as result FROM (SELECT distinct sn, max(created_date) created_date FROM `heartbeat_terminal` WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)  GROUP by sn) as a
		");
		$query4 = $this->db->query("
			SELECT COUNT(*) as result FROM (SELECT distinct sn, max(created_date) created_date FROM `heartbeat_terminal` GROUP by sn) as a
		");

		$value['1'] = $query->row()->result;
		$value['2'] = $query2->row()->result;
		$value['3'] = $query3->row()->result;
		$value['4'] = $query4->row()->result;

		return $value;
	}


	public function getCountByKanwil($valueForLabel,$valueTimer){
		$query = $this->db->query("
			SELECT count(*) as result FROM (SELECT merchant_code, merchant_name, max(created_date) created_date FROM `heartbeat_terminal` where kanwil = '".$valueForLabel."' GROUP BY merchant_code) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			");
		$query2 = $this->db->query("
			SELECT count(*) as result FROM (SELECT merchant_code, merchant_name, max(created_date) created_date FROM `heartbeat_terminal` where kanwil = '".$valueForLabel."' GROUP BY merchant_code) AS A
		");
		$query3 = $this->db->query("
			SELECT COUNT(*) as result FROM (SELECT distinct sn, max(created_date) created_date FROM `heartbeat_terminal` WHERE kanwil = '".$valueForLabel."' and created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)  GROUP by sn) as a
		");
		$query4 = $this->db->query("
			SELECT COUNT(*) as result FROM (SELECT distinct sn, max(created_date) created_date FROM `heartbeat_terminal` where kanwil = '".$valueForLabel."' GROUP by sn) as a
		");

		$value['1'] = $query->row()->result;
		$value['2'] = $query2->row()->result;
		$value['3'] = $query3->row()->result;
		$value['4'] = $query4->row()->result;

		return $value;
	}

	public function getCountByKcp($valueForLabel,$valueTimer){
		$query = $this->db->query("
			SELECT count(*) as result FROM (SELECT merchant_code, merchant_name, max(created_date) created_date FROM `heartbeat_terminal` where kcp = '".$valueForLabel."' GROUP BY merchant_code) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)
			");
		$query2 = $this->db->query("
			SELECT count(*) as result FROM (SELECT merchant_code, merchant_name, max(created_date) created_date FROM `heartbeat_terminal` where kcp = '".$valueForLabel."' GROUP BY merchant_code) AS A
		");
		$query3 = $this->db->query("
			SELECT COUNT(*) as result FROM (SELECT distinct sn, max(created_date) created_date FROM `heartbeat_terminal` WHERE kcp = '".$valueForLabel."' and created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)  GROUP by sn) as a
		");
		$query4 = $this->db->query("
			SELECT COUNT(*) as result FROM (SELECT distinct sn, max(created_date) created_date FROM `heartbeat_terminal` where kcp = '".$valueForLabel."' GROUP by sn) as a
		");

		$value['1'] = $query->row()->result;
		$value['2'] = $query2->row()->result;
		$value['3'] = $query3->row()->result;
		$value['4'] = $query4->row()->result;

		return $value;
	}




}