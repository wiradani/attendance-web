<?php
class ReportModel extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    //--------------EXPORT ALL DATA merchant FROM TERMINAL --------------//
	public function getExportAllMerchantFromTerminal(){
		$query = $this->db->query("SELECT merchant_code, merchant_name, area as MOR, kanwil, area, kcp,address, max(created_date) created_date FROM heartbeat_terminal GROUP BY merchant_code ORDER BY `created_date` DESC");		
		return $query->result();
    }
    
    //--------------EXPORT ALL DATA EDC FROM TERMINAL --------------//
	public function getExportAllEdcFromTerminal(){
		$query = $this->db->query("SELECT sn, merchant_code, merchant_name, device_type, dcm_version, created_date, kanwil, area, kcp,address, area as MOR, IF(substr(merchant_code,2,1) = 1,'COCO','DODO') as COCO_DODO FROM heartbeat_terminal");		
		return $query->result();
	}


}