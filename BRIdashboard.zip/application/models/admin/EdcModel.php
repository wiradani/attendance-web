<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EdcModel extends CI_Model {



//--------------TOTAL--------------//
	public function getDataEdcTotal($valueTimer){
		for ($i=1; $i <= 8; $i++) { 
			$query[$i] = $this->db->query("
				SELECT count(*) as result FROM (SELECT distinct sn FROM `heartbeat_terminal` WHERE substr(merchant_code,1,1) = ".$i.") AS S

			");
			$data_total[$i] = $query[$i]->row()->result;
		}			
		return $data_total;
	}

	public function getTotalMerchant(){
		$query = $this->db->query(" SELECT COUNT( DISTINCT merchant_code) as merchant FROM heartbeat_terminal ");
		return $query->row();
	}

	public function getTotalTerminal(){
		$query = $this->db->query(" SELECT COUNT( DISTINCT sn) as sn FROM heartbeat_terminal ");
		return $query->row();
	}

	public function getTotalArea(){
		$query = $this->db->query(" SELECT COUNT( DISTINCT area) as area FROM heartbeat_terminal ");
		return $query->row();
	}

	public function getTotalKANWIL(){
		$query = $this->db->query(" SELECT COUNT( DISTINCT 	kanwil) as kanwil FROM heartbeat_terminal ");
		return $query->row();
	}

	public function getTotalKCP(){
		$query = $this->db->query(" SELECT COUNT( DISTINCT 	kcp) as kcp FROM heartbeat_terminal ");
		return $query->row();
	}

	public function getTotalActiveTerminal($valueTimer){
		$query = $this->db->query("
			SELECT count(*) as result FROM (SELECT max(created_date) created_date FROM `heartbeat_terminal` GROUP BY merchant_code) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE)");
		return $query->row(); 
	}

	public function getWeekly(){
		$query_date = date("Y-m-d");

		// First day of the month.
		$first =  date('Y-m-01', strtotime($query_date));

		// Last day of the month.
		$last = date('Y-m-t', strtotime($query_date));
		$query = $this->db->query("SELECT DATE(created_date) as date, COUNT(*) as total FROM heartbeat_terminal WHERE created_date BETWEEN $first AND $last GROUP BY WEEK(created_date) ORDER BY created_date");
		
		return $query->result();

	}

	public function getTotalEDCMonthly(){
		$query = $this->db->query("SELECT YEAR(created_date) as year, MONTHNAME(created_date) as month, COUNT( DISTINCT sn) as total_edc FROM heartbeat_terminal WHERE YEAR(created_date) = YEAR(CURRENT_TIMESTAMP) GROUP BY YEAR(created_date), MONTH(created_date), MONTHNAME(created_date) ORDER BY YEAR(created_date), MONTH(created_date)");
		return $query->result();
	}

	// get total edc in current month
	public function getTotalEDCDaily(){
		$query_date = date("Y-m-d");

		// First day of the month.
		$first =  date('Y-m-01', strtotime($query_date));

		// Last day of the month.
		$last = date('Y-m-t', strtotime($query_date));

		$query = $this->db->query("select cast(created_date as date) as date, COUNT(*) as total_edc from heartbeat_terminal where created_date >= ".$first." and created_date < ".$last." group by cast(created_date as date) order by cast(created_date as date) ");
		return $query->result();
	}

	// get total edc in current month 
	public function getEDCWeekly(){
		$day = date('Y-m-01');
		$query = $this->db->query("SELECT DATE(created_date) as date, COUNT(*) as total FROM heartbeat_terminal WHERE created_date >= '$day' GROUP BY WEEK(created_date) ORDER BY created_date");
		
		return $query->result();

	}

	//table
	public function getAllArea($valueTimer){
		$query = $this->db->query("SELECT a.area , total, IF(b.connected IS NULL,0,b.connected) as connected, IF((connected/total)*100 IS NULL,0,(connected/total)*100) percent
							FROM (SELECT count(*) as total, area FROM (SELECT merchant_code, max(created_date) created_date, area FROM `heartbeat_terminal` GROUP BY merchant_code)as A GROUP BY area) as a
						LEFT JOIN (SELECT count(*) as connected, area as mor FROM (SELECT merchant_code, max(created_date) created_date, area  FROM `heartbeat_terminal` GROUP BY merchant_code ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) group by area ) as b ON b.mor = a.area 
			");	
		return $query->result();
	}

	public function getAllKanwil($valueTimer){
		$query = $this->db->query("SELECT a.kanwil , total, IF(b.connected IS NULL,0,b.connected) as connected, IF((connected/total)*100 IS NULL,0,(connected/total)*100) percent
							FROM (SELECT count(*) as total, kanwil FROM (SELECT merchant_code, max(created_date) created_date, kanwil FROM `heartbeat_terminal` GROUP BY merchant_code)as A GROUP BY kanwil) as a
						LEFT JOIN (SELECT count(*) as connected, kanwil as mor FROM (SELECT merchant_code, max(created_date) created_date, kanwil  FROM `heartbeat_terminal` GROUP BY merchant_code ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) group by kanwil ) as b ON b.mor = a.kanwil 
			");	
		return $query->result();
	}

	// ------------------------------ TO EXCEL ------------------------------------  //
	public function Upload_Batch_Edc($filename){
		$this->load->library('upload'); // Load librari upload
		
		$config['upload_path'] = './assets/excel/';
		$config['allowed_types'] = 'xlsx';
		$config['max_size']	= '20000';
		$config['overwrite'] = true;
		$config['file_name'] = $filename;
	
		$this->upload->initialize($config); // Load konfigurasi uploadnya
		if($this->upload->do_upload('file')){ // Lakukan upload dan Cek jika proses upload berhasil
			// Jika berhasil :
			$return = array('result' => 'success', 'file' => $this->upload->data(), 'error' => '');
			return $return;
		}else{
			// Jika gagal :
			$return = array('result' => 'failed', 'file' => '', 'error' => $this->upload->display_errors());
			return $return;
		}
	}

	public function isUnique($data){
		$query = $this->db->query("SELECT * FROM `edc` WHERE sn = '".$data['sn']."' ");
		return $query;
	}


	public function insertEdcExcel($data){
		$this->db->insert('edc', $data);
	}

	public function updateBinExcel($data){

		$query = $this->db->query("
			UPDATE `edc` 
			SET 
			`merchant_code` 	= '".$data['merchant_code']."',
			`merchant_name` 	= '".$data['merchant_name']."',
			`device_type` 	= '".$data['device_type']."',
			`dcm_version` 	= '".$data['dcm_version']."',
			`address` 	= '".$data['address']."',
			`area` 	= '".$data['area']."',
			`kanwil` 	= '".$data['kanwil']."',
			`kcp` 	= '".$data['kcp']."'

			WHERE `sn` 	= '".$data['sn']."' 
		");
        return $this->db->affected_rows();
	}


}