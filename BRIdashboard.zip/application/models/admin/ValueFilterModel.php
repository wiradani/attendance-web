<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ValueFilterModel extends CI_Model {

	public function getValueTimer(){		
		$queryTimer = $this->db->query("SELECT timer FROM valueTimer where id = 2");
		return $queryTimer->row()->timer;
	}

	public function getValueTimerGraph(){		
		$queryTimer = $this->db->query("SELECT timer FROM valueTimer where id = 3");
		return $queryTimer->row()->timer;
	}

	public function getValueFilter(){
		$queryFilter = $this->db->query("SELECT timer FROM valueTimer where id = 4");
		return $queryFilter->row()->timer;
	}

	public function UpdateTimer($timerPost){
		return $this->db->query("UPDATE valueTimer SET timer = '$timerPost' WHERE id = 2");
	}

	public function UpdateTimerGraph($timerPost){
		return $this->db->query("UPDATE valueTimer SET timer = '$timerPost' WHERE id = 3");
	}

	/////////////////////// GET MODEL FILTER ///////////////////////
	public function getForSearchFilter(){
		$query = $this->db->query("
			SELECT distinct area FROM `heartbeat_terminal` GROUP BY area
			");
		$query2 = $this->db->query("
			SELECT distinct area as valueType FROM `heartbeat_terminal` GROUP BY area
			");
		$data['mor'] 	= $query->result();
		$data['type'] 	= $query2->result();
		return $data;
	}
	////////////////////////////////////////////////////////////////


	//--------------GET SINGLE SEARCH --------------//
	public function getSingle_Search($param1, $filter_tolerance){
		$query = $this->db->query("
			SELECT b.merchant_code, b.merchant_name, b.kanwil, b.area, a.sn, a.device_type, a.created_date, IF(a.`created_date` < DATE_SUB(NOW(),INTERVAL $filter_tolerance DAY), 'Disconnected', 'Connected') as status from heartbeat_terminal as a
			LEFT JOIN heartbeat_terminal as b ON b.sn = a.sn
			WHERE a.sn = '".$param1."' and a.created_date > DATE_SUB(NOW(),INTERVAL $filter_tolerance DAY) 
			ORDER BY a.created_date DESC
		");
		return $query->result();	
	}
	public function getSingle_SearchMerchant($param1, $filter_tolerance){
		//$query = $this->db->query("
		//	SELECT merchant_code, merchant_name, sn, device_type, created_date, IF(`created_date` < DATE_SUB(NOW(),INTERVAL $filter_tolerance DAY), 'Disconnected', 'Connected') as status from heartbeat_terminal WHERE merchant_code = '".$param1."' and `created_date` > DATE_SUB(NOW(),INTERVAL $filter_tolerance DAY) ORDER BY `heartbeat_terminal`.`created_date` DESC
		//");
		$query = $this->db->query("
			SELECT a.*, b.created_date, b.status FROM (
				SELECT DISTINCT merchant_code, sn, merchant_name, device_type FROM heartbeat_terminal WHERE merchant_code = '".$param1."'
			) as a 
			LEFT JOIN (
			    SELECT merchant_code, merchant_name, sn, device_type, created_date, IF(`created_date` < DATE_SUB(NOW(),INTERVAL $filter_tolerance DAY), 'Disconnected', 'Connected') as status 
			    from heartbeat_terminal 
			    WHERE merchant_code = '".$param1."' and `created_date` > DATE_SUB(NOW(),INTERVAL $filter_tolerance DAY)
			)as b on b.merchant_code = a.merchant_code and b.sn = a.sn WHERE b.created_date is NOT null");
		return $query->result();	
	}

	//-------------- GET LINE GRAPH --------------//
	public function getLineGraph($param1, $filter_tolerance){
		$query = $this->db->query("
			SELECT DATE(created_date) as myData FROM `heartbeat_terminal` WHERE created_date > DATE_SUB(NOW(),INTERVAL $filter_tolerance DAY) and sn = '".$param1."' GROUP by DATE(created_date) ORDER BY `myData` ASC
		");
		return $query->result();
	}
	public function getLineGraphTime($param1, $filter_tolerance){
		$query = $this->db->query("
			SELECT DISTINCT(myData) FROM (SELECT DATE_FORMAT(created_date, '%Y-%m-%d %H') as myData FROM heartbeat_terminal WHERE created_date > DATE_SUB(NOW(),INTERVAL $filter_tolerance DAY) and sn = '".$param1."' ORDER BY `myData` ASC) AS A
		");
		return $query->result();
	}

	///////////////////// FILTER LOG ACTIVITY /////////////////////////////

	// public function getUser(){
	// 	$query = $this->db->query("
	// 		SELECT distinct substr(merchant_code,1,1) as valueMor FROM `heartbeat_terminal` GROUP BY substr(merchant_code, 1,1)
	// 		");
	// 	$query2 = $this->db->query("
	// 		SELECT distinct substr(merchant_code,2,1) as valueType FROM `heartbeat_terminal` GROUP BY substr(merchant_code, 2,1)
	// 		");
	// 	$data['mor'] 	= $query->result();
	// 	$data['type'] 	= $query2->result();
	// 	return $data;
	// }

	public function getSerialNumberSearch($merchant_code){
		$query = $this->db->query("
			SELECT sn FROM `heartbeat_terminal` WHERE merchant_code = '".$merchant_code."'
		");
		return $query->result();
	}

	public function getLineBySerialNumberSearchHour($value_search, $filter_tolerance){
		$value = [];
		for ($i=0; $i < count($value_search); $i++) { 
			$query[$i] = $this->db->query("
				SELECT DISTINCT(myData) FROM (SELECT DATE_FORMAT(created_date, '%Y-%m-%d %H') as myData, sn FROM heartbeat_terminal WHERE created_date > DATE_SUB(NOW(),INTERVAL $filter_tolerance DAY) and sn = '".$value_search[$i]->sn."' ORDER BY `myData` ASC) AS A
			");	
			$value[$i] = $query[$i]->result();
		}
		return $value;
	}

	public function getLineBySerialNumberSearchDay($value_search, $filter_tolerance){
		$value = [];
		for ($i=0; $i < count($value_search); $i++) { 
			$query = $this->db->query("
				SELECT DATE(created_date) as myData, sn FROM `heartbeat_terminal` WHERE created_date > DATE_SUB(NOW(),INTERVAL $filter_tolerance DAY) and sn = '".$value_search[$i]->sn."' GROUP by DATE(created_date) ORDER BY `myData` ASC
			");	
			$value[$i] = $query->result();
		}
		return $value;
	}

	// public function getLineByMORSearch($duration_type, $valueTimer, $mor){
	// 	if(strtolower($duration_type) === "day"){
	// 		$query = $this->db->query("
	// 			SELECT mor, count(DISTINCT merchant_code) as merchant_connected, count(DISTINCT sn) sn_connected, total_spbu merchant_total, total_terminal sn_total, created_date
	// 			FROM (
	// 			    SELECT a.*, b.total_spbu, b.total_terminal FROM (
	// 			        SELECT merchant_code,substr(a.merchant_code,1,1) as mor,mid,created_date,sn FROM (
	// 			            SELECT merchant_code, mid, sn, DATE(created_date) created_date FROM `heartbeat_terminal` 
	// 			            WHERE created_date >= DATE_SUB(NOW(),INTERVAL $valueTimer DAY) and 
	// 			            substr(merchant_code,1,1) = '".$mor."'
	// 			        ) as a group by merchant_code, mid,created_date,sn
	// 			    ) as a 
	// 			    left join (
	// 			        select mor, count(DISTINCT merchant_code) total_spbu, COUNT(DISTINCT sn) total_terminal from (
    //                         select merchant_code, substr(merchant_code,1,1) as mor, sn from heartbeat_terminal
    //                     )as a group by mor 
	// 			    ) as b on b.mor = a.mor
	// 			) as a group by mor, created_date
	// 			order by created_date desc
	// 		");
	// 	}else{
	// 		$query = $this->db->query("
	// 			SELECT mor, count(DISTINCT merchant_code) as merchant_connected, count(DISTINCT sn) sn_connected, total_spbu merchant_total, total_terminal sn_total, created_date
	// 			FROM (
	// 			    SELECT a.*, b.total_spbu, b.total_terminal FROM (
	// 			        SELECT merchant_code,substr(a.merchant_code,1,1) as mor,mid,created_date,sn FROM (
	// 			            SELECT merchant_code, mid, sn, DATE_FORMAT(created_date, '%Y-%m-%d %H') created_date FROM `heartbeat_terminal` 
	// 			            WHERE created_date >= DATE_SUB(NOW(),INTERVAL $valueTimer DAY) and 
	// 			            substr(merchant_code,1,1) = '".$mor."'
	// 			        ) as a group by merchant_code, mid,created_date,sn
	// 			    ) as a 
	// 			    left join (
	// 			        select mor, count(DISTINCT merchant_code) total_spbu, COUNT(DISTINCT sn) total_terminal from (
    //                         select merchant_code, substr(merchant_code,1,1) as mor, sn from heartbeat_terminal
    //                     )as a group by mor 
	// 			    ) as b on b.mor = a.mor
	// 			) as a group by mor, created_date
	// 			order by created_date desc
	// 		");
	// 	}
		
	// 	return $query->result();
	// }

	public function getLineByKANWILSearch($duration_type, $valueTimer, $treg){
		if($treg == ""){
			$query = $this->db->query("SELECT a.*, b.total_merchant merchant_total, b.total_terminal sn_total FROM (
				    SELECT kanwil, count(DISTINCT merchant_code) merchant_connected, count(DISTINCT sn) sn_connected FROM (
				        SELECT sn,merchant_code, created_date, kanwil,area FROM `heartbeat_terminal` 
				        where created_date > DATE_SUB(NOW(),INTERVAL $valueTimer DAY)
				    ) as a group by kanwil
				) as a 
				left join (
				    select kanwil, count(DISTINCT merchant_code) total_merchant, COUNT(DISTINCT sn) total_terminal from (
				        select merchant_code, kanwil, sn from heartbeat_terminal
				    )as a group by kanwil 
				) as b on b.kanwil = a.kanwil 
				ORDER BY kanwil asc");
		}else{
			if(strtolower($duration_type) === "day"){
				$query = $this->db->query("
					SELECT kanwil, count(DISTINCT merchant_code) as merchant_connected, count(DISTINCT sn) sn_connected, total_merchant merchant_total, total_terminal sn_total, created_date
					FROM (
	                    SELECT a.*, b.total_merchant, b.total_terminal FROM (
	                        SELECT merchant_code,kanwil,created_date,sn FROM (
	                            SELECT a.merchant_code, a.sn, DATE(a.created_date) created_date, b.kanwil
	                            FROM `heartbeat_terminal` as a 
	                            left join heartbeat_terminal as b on b.merchant_code = a.merchant_code and b.sn = a.sn
	                            WHERE a.created_date >= DATE_SUB(NOW(),INTERVAL $valueTimer DAY) and 
	                            b.kanwil LIKE '%$kanwil%' 
	                        ) as a group by kanwil,merchant_code,created_date,sn
	                    ) as a 
	                    left join (
	                        select kanwil, count(DISTINCT merchant_code) total_merchant, COUNT(DISTINCT sn) total_terminal from (
	                            select merchant_code, kanwil, sn from heartbeat_terminal
	                        )as a group by kanwil 
	                    ) as b on b.kanwil = a.kanwil
	                ) as a group by kanwil, created_date
					order by created_date desc
				");
			}else{
				$query = $this->db->query("
					SELECT kanwil, count(DISTINCT merchant_code) as merchant_connected, count(DISTINCT sn) sn_connected, total_merchant merchant_total, total_terminal sn_total, created_date
					FROM (
	                    SELECT a.*, b.total_merchant, b.total_terminal FROM (
	                        SELECT merchant_code,kanwil,created_date,sn FROM (
	                            SELECT a.merchant_code, a.sn, DATE_FORMAT(a.created_date, '%Y-%m-%d %H') created_date, b.kanwil
	                            FROM `heartbeat_terminal` as a 
	                            left join heartbeat_terminal as b on b.merchant_code = a.merchant_code and b.sn = a.sn
	                            WHERE a.created_date >= DATE_SUB(NOW(),INTERVAL $valueTimer DAY) and 
	                            b.kanwil LIKE '%$kanwil%' 
	                        ) as a group by kanwil,merchant_code,created_date,sn
	                    ) as a 
	                    left join (
	                        select kanwil, count(DISTINCT merchant_code) total_merchant, COUNT(DISTINCT sn) total_terminal from (
	                            select merchant_code, kanwil, sn from heartbeat_terminal
	                        )as a group by kanwil 
	                    ) as b on b.kanwil = a.kanwil
	                ) as a group by kanwil, created_date
					order by created_date desc
				");
			}
		}
		
		
		return $query->result();
	}

	public function getLineByAREASearch($duration_type, $valueTimer, $area){
		if($area == ""){
			$query = $this->db->query("
				SELECT a.*, b.total_spbu merchant_total, b.total_terminal sn_total FROM (
				    SELECT area, count(DISTINCT merchant_code) merchant_connected, count(DISTINCT sn) sn_connected FROM (
				        SELECT sn,merchant_code, created_date, area FROM `heartbeat_terminal` 
				        where created_date > DATE_SUB(NOW(),INTERVAL $valueTimer DAY)
				    ) as a group by area
				) as a 
				left join (
				    select area, count(DISTINCT merchant_code) total_spbu, COUNT(DISTINCT sn) total_terminal from (
				        select merchant_code, area, sn from heartbeat_terminal
				    )as a group by area 
				) as b on b.area = a.area 
				ORDER BY sn_connected desc");
		}else{
			if(strtolower($duration_type) === "day"){
				$query = $this->db->query("
					SELECT area, count(DISTINCT merchant_code) as merchant_connected, count(DISTINCT sn) sn_connected, total_spbu merchant_total, total_terminal sn_total, created_date
					FROM (
	                    SELECT a.*, b.total_spbu, b.total_terminal FROM (
	                        SELECT merchant_code,area,created_date,sn FROM (
	                            SELECT a.merchant_code, a.sn, DATE(a.created_date) created_date, b.area
	                            FROM `heartbeat_terminal` as a 
	                            left join heartbeat_terminal as b on b.merchant_code = a.merchant_code and b.sn = a.sn
	                            WHERE a.created_date > DATE_SUB(NOW(),INTERVAL $valueTimer DAY) and 
	                            b.area = '$area'
	                        ) as a group by area,merchant_code,created_date,sn
	                    ) as a 
	                    left join (
	                        select area, count(DISTINCT merchant_code) total_spbu, COUNT(DISTINCT sn) total_terminal from (
	                            select merchant_code, area, sn from heartbeat_terminal
	                        )as a group by area 
	                    ) as b on b.area = a.area
	                ) as a group by area, created_date 
					order by created_date desc
				");
			}else{
				$query = $this->db->query("
					SELECT area, count(DISTINCT merchant_code) as merchant_connected, count(DISTINCT sn) sn_connected, total_spbu merchant_total, total_terminal sn_total, created_date
					FROM (
	                    SELECT a.*, b.total_spbu, b.total_terminal FROM (
	                        SELECT merchant_code,area,created_date,sn FROM (
	                            SELECT a.merchant_code, a.sn, DATE_FORMAT(a.created_date, '%Y-%m-%d %H') created_date, b.area
	                            FROM `heartbeat_terminal` as a 
	                            left join heartbeat_terminal as b on b.merchant_code = a.merchant_code and b.sn = a.sn
	                            WHERE a.created_date >= DATE_SUB(NOW(),INTERVAL $valueTimer DAY) and 
	                            b.area = '$area'
	                        ) as a group by area,merchant_code,created_date,sn
	                    ) as a 
	                    left join (
	                        select area, count(DISTINCT merchant_code) total_spbu, COUNT(DISTINCT sn) total_terminal from (
	                            select merchant_code, area, sn from heartbeat_terminal
	                        )as a group by area 
	                    ) as b on b.area = a.area
	                ) as a group by area, created_date
					order by created_date desc
				");
			}
		}
		return $query->result();
	}

	public function getLine($valueTimer){
		$day = date('Y-m-01');
		$query = $this->db->query("
				SELECT a.*, b.total_spbu merchant_total, b.total_terminal sn_total FROM (
					SELECT area, count(DISTINCT merchant_code) merchant_connected, count(DISTINCT sn) sn_connected FROM (
						SELECT sn,merchant_code, created_date, area FROM `heartbeat_terminal` 
						where created_date > DATE_SUB(NOW(),INTERVAL $valueTimer DAY)
					) as a group by area
				) as a 
				left join (
					select area, count(DISTINCT merchant_code) total_spbu, COUNT(DISTINCT sn) total_terminal from (
						select merchant_code, area, sn from heartbeat_terminal
					)as a group by area 
				) as b on b.area = a.area 
				ORDER BY sn_connected desc
				");
		return $query->result();

	}
	
	public function getLineKanwil($valueTimer){
		$query = $this->db->query("
				SELECT a.*, b.total_spbu merchant_total, b.total_terminal sn_total FROM (
					SELECT kanwil, count(DISTINCT merchant_code) merchant_connected, count(DISTINCT sn) sn_connected FROM (
						SELECT sn,merchant_code, created_date, kanwil FROM `heartbeat_terminal` 
						where created_date > DATE_SUB(NOW(),INTERVAL $valueTimer DAY)
					) as a group by kanwil
				) as a 
				left join (
					select kanwil, count(DISTINCT merchant_code) total_spbu, COUNT(DISTINCT sn) total_terminal from (
						select merchant_code, kanwil, sn from heartbeat_terminal
					)as a group by kanwil 
				) as b on b.kanwil = a.kanwil 
				ORDER BY sn_connected desc
				");
		return $query->result();
	}


	public function getLineKCP($valueTimer){
		$query = $this->db->query("
				SELECT a.*, b.total_spbu merchant_total, b.total_terminal sn_total FROM (
					SELECT kcp, count(DISTINCT merchant_code) merchant_connected, count(DISTINCT sn) sn_connected FROM (
						SELECT sn,merchant_code, created_date, kcp FROM `heartbeat_terminal` 
						where created_date > DATE_SUB(NOW(),INTERVAL $valueTimer DAY)
					) as a group by kcp
				) as a 
				left join (
					select kcp, count(DISTINCT merchant_code) total_spbu, COUNT(DISTINCT sn) total_terminal from (
						select merchant_code, kcp, sn from heartbeat_terminal
					)as a group by kcp 
				) as b on b.kcp = a.kcp 
				ORDER BY sn_connected desc
				");
		return $query->result();
	}
}
?>