<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DataModelKcp extends CI_Model {

    public function getTableKcp($valueTimer){
		$query = $this->db->query("SELECT a.*, IF(b.connect IS NULL,0,b.connect) as connect, IF(c.disconnect is null,0,c.disconnect) as disconnect, IF(e.edc_connect IS NULL,0,e.edc_connect) as edc_connect, IF(f.edc_disconnect IS NULL,0,f.edc_disconnect) as edc_disconnect, g.edc_total FROM (
				SELECT count(*) as total, kcp as kcp FROM (SELECT merchant_code, max(created_date) created_date, kcp FROM `heartbeat_terminal` GROUP BY merchant_code) AS A group by kcp) as a 
				LEFT JOIN (SELECT count(*) as connect, kcp as mor FROM (SELECT merchant_code, max(created_date) created_date, kcp FROM `heartbeat_terminal` GROUP BY merchant_code ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) group by kcp ) as b ON b.mor = a.kcp 
				LEFT JOIN ( SELECT count(*) as disconnect, kcp as mor FROM (SELECT merchant_code, max(created_date) created_date,kcp FROM `heartbeat_terminal` GROUP BY merchant_code ) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL '$valueTimer' MINUTE) group by kcp) as c ON c.mor = a.kcp 
                LEFT JOIN (SELECT count(*) as edc_connect, kcp as mor FROM (SELECT sn, merchant_code, max(created_date) created_date, kcp FROM `heartbeat_terminal` GROUP BY sn ) AS A WHERE created_date > DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) group by kcp ) as e ON e.mor = a.kcp
				LEFT JOIN ( SELECT count(*) as edc_disconnect, kcp as mor FROM (SELECT merchant_code, max(created_date) created_date, kcp FROM `heartbeat_terminal` GROUP BY sn ) AS A WHERE created_date < DATE_SUB(NOW(),INTERVAL $valueTimer MINUTE) group by kcp) as f ON f.mor = a.kcp
				LEFT JOIN (SELECT count(*) as edc_total, kcp as mor FROM (SELECT merchant_code, max(created_date) created_date, kcp FROM `heartbeat_terminal` GROUP BY sn) AS A group by kcp) as g ON g.mor = a.kcp");      
        $data['mor'] = $query->result();		
		return $data;
	}
}